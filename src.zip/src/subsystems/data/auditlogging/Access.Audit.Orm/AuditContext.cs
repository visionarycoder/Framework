﻿using Microsoft.EntityFrameworkCore;
using Wsdot.Idl.Access.Audit.Orm.Models;

namespace Wsdot.Idl.Access.Audit.Orm;

public class AuditContext(DbContextOptions<AuditContext> options)
    : DbContext(options)
{

    public DbSet<ApplicationLog> ApplicationLogs { get; set; } = null!;
    public DbSet<ApplicationLogAction> ApplicationLogActions { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AuditContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }
}
