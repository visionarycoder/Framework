using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using Wsdot.Idl.Access.Audit.Orm.Models;

namespace Wsdot.Idl.Access.Audit.Orm.Configs;

public sealed class ApplicationLogConfig : IEntityTypeConfiguration<ApplicationLog>
{
    public void Configure(EntityTypeBuilder<ApplicationLog> builder)
    {
        builder.ToTable(nameof(ApplicationLog), "dbo");
        builder.HasKey(x => x.ApplicationLogId).HasName("XPKApplicationLog");
        builder.Property(x => x.ApplicationLogId).ValueGeneratedOnAdd();
        builder.Property(x => x.LogNote).HasMaxLength(5000).IsUnicode(false);
        builder.Property(x => x.LogDate).HasColumnType("datetime2(7)");

        builder.HasOne(x => x.ApplicationLogAction)
            .WithMany(a => a.ApplicationLogs)
            .HasForeignKey(x => x.ApplicationLogActionId)
            .HasConstraintName("FKApplicationLogActionApplicationLogApplicationLogActionId");
    }
}