using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using Wsdot.Idl.Access.Audit.Orm.Models;

namespace Wsdot.Idl.Access.Audit.Orm.Configs;

public sealed class ApplicationLogActionConfig : IEntityTypeConfiguration<ApplicationLogAction>
{
    public void Configure(EntityTypeBuilder<ApplicationLogAction> builder)
    {
        builder.ToTable(nameof(ApplicationLogAction), "dbo");
        builder.HasKey(x => x.ApplicationLogActionId).HasName("XPKApplicationLogAction");
        builder.Property(x => x.ApplicationLogActionId).ValueGeneratedOnAdd();
        builder.Property(x => x.ApplicationLogActionName).HasMaxLength(50).IsUnicode(false);
        builder.Property(x => x.ActiveFlag).HasDefaultValue(true);
    }
}