using System;
// ReSharper disable PropertyCanBeMadeInitOnly.Global

namespace Wsdot.Idl.Access.Audit.Orm.Models;

public class ApplicationLogAction
{

    public int ApplicationLogActionId { get; set; }
    public string? ApplicationLogActionName { get; set; }
    public bool? ActiveFlag { get; set; } // DEFAULT 1, nullable

    // Navigation
    public ICollection<ApplicationLog> ApplicationLogs { get; set; } = new List<ApplicationLog>();

}