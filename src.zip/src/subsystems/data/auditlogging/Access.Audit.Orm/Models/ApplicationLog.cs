using System;

namespace Wsdot.Idl.Access.Audit.Orm.Models;

public class ApplicationLog
{
    public int ApplicationLogId { get; set; }
    public int? ApplicationLogActionId { get; set; }
    public string? LogNote { get; set; }
    public DateTime LogDate { get; set; }
    public int? LogUserId { get; set; }

    // Navigation
    public ApplicationLogAction? ApplicationLogAction { get; set; }
}