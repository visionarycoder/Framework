﻿using Wsdot.Idl.Manager.Auditor.Contract.Models;

namespace Wsdot.Idl.Manager.Auditor.Contract;

public interface IAuditManager
{
    Task<bool> LogEventAsync(AuditEvent auditEvent, CancellationToken ct = default);
}
