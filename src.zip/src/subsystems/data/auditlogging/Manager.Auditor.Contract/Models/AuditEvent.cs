﻿namespace Wsdot.Idl.Manager.Auditor.Contract.Models;

public record AuditEvent(string EventType, string Description, string? UserId);