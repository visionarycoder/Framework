﻿using Wsdot.Idl.Access.Audit.Contract.Models;

namespace Wsdot.Idl.Access.Audit.Contract;

public interface IAuditAccess
{
    Task<bool> LogEventAsync(AuditEvent auditEvent, CancellationToken ct = default);
}
