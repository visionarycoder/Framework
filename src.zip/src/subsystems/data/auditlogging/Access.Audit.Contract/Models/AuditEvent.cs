﻿namespace Wsdot.Idl.Access.Audit.Contract.Models;

public record AuditEvent(string EventType, string Description, string? UserId);