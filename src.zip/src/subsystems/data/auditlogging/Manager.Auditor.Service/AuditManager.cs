﻿using Microsoft.Extensions.Logging;
using Wsdot.Idl.Access.Audit.Contract;
using Wsdot.Idl.Manager.Auditor.Contract;
using Wsdot.Idl.Manager.Auditor.Contract.Models;

namespace Wsdot.Idl.Manager.Auditor.Service;

public class AuditManager(ILogger<AuditManager> logger, IAuditAccess auditAccess) : IAuditManager
{
    public async Task<bool> LogEventAsync(AuditEvent auditEvent, CancellationToken ct = default)
    {
        logger.LogInformation("Logging audit event: {AuditEvent}", auditEvent);
        return await auditAccess.LogEventAsync(auditEvent.ToAccess(), ct);
    }

}
