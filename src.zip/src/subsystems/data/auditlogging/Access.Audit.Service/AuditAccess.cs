﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Wsdot.Idl.Access.Audit.Contract;
using Wsdot.Idl.Access.Audit.Contract.Models;
using Wsdot.Idl.Access.Audit.Orm;
using Wsdot.Idl.Ifx.Services; 

namespace Wsdot.Idl.Access.Audit.Service;

public sealed class AuditAccess(ILogger<AuditAccess> logger, AuditContext ctx)
    : ServiceBase<AuditAccess>(logger), IAuditAccess
{

    public async Task<bool> LogEventAsync(AuditEvent auditEvent, CancellationToken ct = default)
    {
        
        if (string.IsNullOrWhiteSpace(auditEvent.Description) || string.IsNullOrWhiteSpace(auditEvent.EventType))
        {
            return false;
        }

        // Map AuditEvent -> contract ApplicationLog
        var entity = new Orm.Models.ApplicationLog
        {
            ApplicationLogActionId = null,
            ApplicationLogAction = null,
            LogNote = auditEvent.Description,
            LogDate = DateTime.UtcNow,
            LogUserId = int.TryParse(auditEvent.UserId, out var userId) ? userId : 9999 // 9999 = system
        };

        // Resolve action id by name if it already exists
        var action = await ctx.ApplicationLogActions.AsNoTracking().FirstOrDefaultAsync(a => a.ApplicationLogActionName == auditEvent.EventType, ct);
        if (action is not null)
        {
            entity.ApplicationLogActionId = action.ApplicationLogActionId;
        }

        ctx.ApplicationLogs.Add(entity);
        var count = await ctx.SaveChangesAsync(ct);
        var ok = count > 0;
        if (ok)
        {
            logger.LogInformation("Audit event logged: {EventType}", auditEvent.EventType);
        }
        else
        {
            logger.LogWarning("Failed to log audit event: {EventType}", auditEvent.EventType);
        }
        return ok;

    }

}