﻿using System.Data.Common;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;

namespace Ifx.Data.AuditLogging;

public class AuditInterceptor(ILogger<AuditInterceptor> logger, AuditLogger auditLogger) : DbCommandInterceptor
{

    public override async ValueTask<InterceptionResult<DbDataReader>> ReaderExecutingAsync(DbCommand command, CommandEventData eventData, InterceptionResult<DbDataReader> result, CancellationToken cancellationToken)
    {
#if DEBUG
        logger.LogInformation("Executing command: {CommandText}", command.CommandText);
#else       
        // Don't leak sensitive information in production logs
        logger.LogInformation($"Executing {nameof(AuditInterceptor)}.{nameof(ReaderExecutingAsync)}().");
#endif
        var auditEvent = new AuditEvent("DatabaseCommand", command.CommandText);
        await auditLogger.LogAsync(auditEvent);
        return await base.ReaderExecutingAsync(command, eventData, result, cancellationToken);
    }
}