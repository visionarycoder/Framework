﻿namespace Ifx.Data.AuditLogging;

public record AuditEvent(string EventType, string Description);