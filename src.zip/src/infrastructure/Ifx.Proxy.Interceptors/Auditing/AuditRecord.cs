﻿namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Auditing;

public sealed record AuditRecord(DateTimeOffset At, string Contract, string Method, string Mode, string CorrelationId, string? TenantId, string? PrincipalId, string? Name, string? Email, string Outcome, string? ErrorType, long DurationMs);