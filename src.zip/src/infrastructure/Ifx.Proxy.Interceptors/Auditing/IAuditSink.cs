﻿namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Auditing;

public interface IAuditSink
{
    Task WriteAsync(AuditRecord record, CancellationToken ct);
}