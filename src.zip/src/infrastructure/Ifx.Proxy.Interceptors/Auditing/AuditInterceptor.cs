﻿using Wsdot.Idl.Ifx.Messaging.Cqrs;

namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Auditing;

public sealed class AuditInterceptor(IAuditSink sink) : IOrderedInterceptor
{
    public int Order => 200;

    public async Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var req = ctx.Args.FirstOrDefault() as IServiceMessageRequest;
        var corr = req?.CorrelationId ?? Guid.NewGuid();
        var tenant = req?.Metadata.GetValueOrDefault(ServiceMessageMetadata.TenantId);
        var pid = req?.Metadata.GetValueOrDefault(ServiceMessageMetadata.PrincipalId);
        var name = req?.Metadata.GetValueOrDefault(ServiceMessageMetadata.Name);
        var email = req?.Metadata.GetValueOrDefault(ServiceMessageMetadata.Email);
        var mode = ctx.Items.TryGetValue("proxy.mode", out var m) ? m?.ToString() ?? "Service" : "Service";

        try
        {
            var result = await next(ctx).ConfigureAwait(false);
            await sink.WriteAsync(new AuditRecord(DateTimeOffset.UtcNow, ctx.Contract.FullName!, ctx.Method.Name, mode, corr.ToString(), tenant, pid, name, email, "Success", null, sw.ElapsedMilliseconds), ctx.CancellationToken);
            return result;
        }
        catch (Exception ex)
        {
            await sink.WriteAsync(new AuditRecord(DateTimeOffset.UtcNow, ctx.Contract.FullName!, ctx.Method.Name, mode, corr.ToString(), tenant, pid, name, email, "Failure", ex.GetType().Name, sw.ElapsedMilliseconds), ctx.CancellationToken);
            throw;
        }
    }

    

}