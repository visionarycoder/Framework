﻿using Microsoft.Extensions.Caching.Memory;

namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Caching;

public sealed class CacheInterceptor(IMemoryCache cache, AttributePolicyProvider policies) : IOrderedInterceptor
{
    public int Order => 40;

    public Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        var hints = policies.Get(ctx.Method);
        if (!(hints.CacheSeconds is int ttl) || !ctx.Method.ReturnType.IsGenericType) return next(ctx);

        var key = $"{ctx.Contract.FullName}:{ctx.Method.Name}:{string.Join("|", ctx.Args.Select(a => a?.GetHashCode() ?? 0))}";
        if (cache.TryGetValue(key, out var hit)) return Task.FromResult(hit);

        return DoAsync();
        async Task<object?> DoAsync()
        {
            var value = await next(ctx);
            cache.Set(key, value, TimeSpan.FromSeconds(ttl));
            return value;
        }
    }
}