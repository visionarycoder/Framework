﻿using System.Diagnostics;
using System.Diagnostics.Metrics;
using Microsoft.Extensions.Logging;

namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Telemetry;

public sealed class TelemetryInterceptor(ILogger<TelemetryInterceptor> log) : IOrderedInterceptor
{

    public const string ACTIVITY_SOURCE_NAME = "Ifx.Proxy";
    public const string METER_NAME = "Ifx.Proxy";
    public const string HISTOGRAM_NAME = "ifx_proxy_duration_ms";
    public const string COUNTER_NAME = "ifx_proxy_errors_total";
    public const string CONTRACT = "contract";
    public const string METHOD = "method";

    private static readonly ActivitySource source = new(ACTIVITY_SOURCE_NAME);
    private static readonly Meter meter = new(METER_NAME);
    private static readonly Histogram<double> duration = meter.CreateHistogram<double>(HISTOGRAM_NAME);
    private static readonly Counter<long> errors = meter.CreateCounter<long>(COUNTER_NAME);

    public int Order => -200;

    public async Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {

        ArgumentNullException.ThrowIfNull(ctx);
        ArgumentNullException.ThrowIfNull(next);

        using var activity = source.StartActivity($"{ctx.Contract.FullName}.{ctx.Method.Name}", ActivityKind.Internal);
        var started = Stopwatch.GetTimestamp();

        try
        {
            var result = await next(ctx).ConfigureAwait(false);
            duration.Record(Stopwatch.GetElapsedTime(started).TotalMilliseconds, new KeyValuePair<string, object?>(CONTRACT, ctx.Contract.FullName), new KeyValuePair<string, object?>(METHOD, ctx.Method.Name));
            return result;
        }
        catch (Exception ex)
        {
            activity?.SetStatus(ActivityStatusCode.Error, ex.Message);
            errors.Add(1, new KeyValuePair<string, object?>(CONTRACT, ctx.Contract.FullName), new KeyValuePair<string, object?>(METHOD, ctx.Method.Name));
            log.LogError(ex, "Proxy failure {Contract}.{Method}", ctx.Contract.FullName, ctx.Method.Name);
            throw;
        }

    }
   
}