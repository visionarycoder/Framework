﻿namespace Wsdot.Idl.Ifx.Proxy.Service.Interceptors.Resilience;

public static class ProxyErrorClassifier
{
    public static bool IsTransient(Exception ex) => ex is TimeoutException || (ex.Data["IsTransient"] as bool?) == true;
}