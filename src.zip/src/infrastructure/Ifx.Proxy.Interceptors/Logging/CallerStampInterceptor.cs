﻿using System.Diagnostics;
using Wsdot.Idl.Ifx.Messaging.Cqrs;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Logging;

public sealed class CallerStampInterceptor(Wsdot.Idl.Ifx.Security.ICallerContext caller) : IOrderedInterceptor
{
    public int Order => -180;

    public Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        var user = caller.Current;
        ctx.Items["user"] = user;
        Activity.Current?.SetTag("user.id", user.PrincipalId);
        Activity.Current?.SetTag("user.tenant", user.TenantId);

        if (ctx.Args.FirstOrDefault() is ServiceMessageRequest req)
            req.StampUser(user);

        return next(ctx);
    }
}