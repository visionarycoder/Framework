﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Wsdot.Idl.Ifx.Proxy;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddProxies(this IServiceCollection services, Action<ProxyOptions>? configure = null)
    {
        services.TryAddSingleton<ModeResolver>();
        services.TryAddSingleton<ProxyFactory>();
        services.TryAddSingleton<IProxyFactory, HybridProxyFactory>();
        if (configure is not null)
        {
            services.Configure(configure);
        }
        return services;
    }
}