﻿namespace Wsdot.Idl.Ifx.Proxy;

public interface IInterceptor
{
    Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next);
}