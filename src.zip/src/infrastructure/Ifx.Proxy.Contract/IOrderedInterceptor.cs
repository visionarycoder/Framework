﻿namespace Wsdot.Idl.Ifx.Proxy;

public interface IOrderedInterceptor : IInterceptor
{
    int Order { get; }
}