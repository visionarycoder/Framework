﻿namespace Wsdot.Idl.Ifx.Proxy;

public interface ICallerContext
{
    string? TenantId { get; }
    string? PrincipalId { get; }
    bool HasPermission(string contract, string method);
}