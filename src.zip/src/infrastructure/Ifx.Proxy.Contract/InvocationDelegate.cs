﻿namespace Wsdot.Idl.Ifx.Proxy;

public delegate Task<object?> InvocationDelegate(InvocationContext context);