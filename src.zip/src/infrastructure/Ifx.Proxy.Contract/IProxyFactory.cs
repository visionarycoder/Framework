﻿namespace Wsdot.Idl.Ifx.Proxy;

public interface IProxyFactory
{
    T Create<T>() where T : class;
}