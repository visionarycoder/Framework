﻿namespace Wsdot.Idl.Ifx.Proxy.Interceptors;

public enum ProxyMode { Service, Emulator, Simulator }