﻿namespace Wsdot.Idl.Ifx.Proxy;

public interface IInvocationClient
{
    Task<object?> InvokeAsync(InvocationEnvelope envelope);
}