﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Wsdot.Idl.Ifx.Components;

public interface IModule
{
    void Add(IServiceCollection services, IConfiguration configuration);
}