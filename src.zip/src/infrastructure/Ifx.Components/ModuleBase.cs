﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Wsdot.Idl.Ifx.Components;
public abstract class ModuleBase : IModule
{

    public virtual void Add(IServiceCollection services, IConfiguration configuration)
    {
    }

    /// <summary>
    /// Verifies the arguments passed to the Add method.
    /// </summary>
    /// <param name="services"></param>
    /// <param name="configuration"></param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void VerifyNotNull(IServiceCollection services, IConfiguration configuration)
    {
        VerifyNotNull(services);
        VerifyNotNull(configuration);
    }

    /// <summary>
    /// Verifies the arguments passed to the Add method.
    /// </summary>
    /// <param name="services"></param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void VerifyNotNull(IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);
    }

    /// <summary>
    /// Verifies the arguments passed to the Add method.
    /// </summary>
    /// <param name="configuration"></param>
    /// <exception cref="ArgumentNullException"></exception>
    public static void VerifyNotNull(IConfiguration configuration)
    {
        ArgumentNullException.ThrowIfNull(configuration);
    }

}
