﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.Loader;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Wsdot.Idl.Ifx.Components;

public static class ModuleLoader
{

    public static IServiceCollection AddModules(this IServiceCollection services, IConfiguration configuration)
    {

        services = services ?? throw new ArgumentNullException(nameof(services));
        configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        using var tempProvider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = false });

        Trace.TraceInformation("{0}.{1}({2},{3}) called.", nameof(ModuleLoader), nameof(AddModules), nameof(services), nameof(configuration));

        // Load every managed assembly in the output directory
        foreach (var path in Directory.EnumerateFiles(AppContext.BaseDirectory, "*.dll"))
        {
            try
            {
                AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
            }
            catch (BadImageFormatException)
            {
                // native DLL – skip
            }
            catch (FileLoadException)
            {
                // already loaded – skip
            }
        }

        // Discover IModule implementations
        AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(SafeGetTypes)
            .Where(t => t is { IsClass: true, IsAbstract: false } && typeof(IModule).IsAssignableFrom(t))
            .Distinct()
            .ToList()
            .ForEach(moduleType =>
            {
                try
                {
                    var module = (IModule)ActivatorUtilities.CreateInstance(tempProvider, moduleType);
                    module.Add(services, configuration);
                }
                catch (Exception ex)
                {
                    Trace.TraceWarning($"ModuleLoader: failed to activate {moduleType.FullName}: {ex.Message}");
                }
            });

        return services;

    }

    private static IEnumerable<Type> SafeGetTypes(Assembly assembly)
    {
        try
        {
            return assembly.GetExportedTypes();
        }
        catch (ReflectionTypeLoadException ex)
        {
            Trace.TraceWarning(ex.Message);
            return ex.Types.Where(t => t is not null)!;
        }
        catch (FileNotFoundException ex)
        {
            Trace.TraceWarning(ex.Message);
            return [];
        }
        catch (NotSupportedException ex)
        {
            Trace.TraceWarning(ex.Message);
            return [];
        }
        catch (Exception ex)
        {
            Trace.TraceWarning(ex.Message);
            return [];
        }
    }
}
