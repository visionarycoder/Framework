﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Ifx.Filtering.EFCore.UnitTests")]