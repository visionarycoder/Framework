﻿using Microsoft.EntityFrameworkCore;
using LinqQueryableExtensions = Wsdot.Idl.Ifx.Filtering.Extensions.QueryableExtensions;
// ReSharper disable InvokeAsExtensionMethod

namespace Wsdot.Idl.Ifx.Filtering;

public static class SqlQueryableExtensions<T>
{

    public static IQueryable<T> ApplyCriterion(IQueryable<T> query, Criterion criterion, LinqQueryableExtensions.FilterType filterType)
    {

        if (filterType == LinqQueryableExtensions.FilterType.Linq)
        {
            // Do not simplify.  Use the explicit naming to avoid using the EF library on a pure C# LINQ query.
            return LinqQueryableExtensions.ApplyCriterion(query, criterion, filterType);
        }

        var propertyName = criterion.PropertyName;
        var value = criterion.PropertyValue?.ToString() ?? string.Empty;

        return criterion.comparisonType switch
        {
            ComparisonType.Equals => query.Where(e => EF.Property<object>(e, propertyName).Equals(value)),
            ComparisonType.NotEquals => query.Where(e => !EF.Property<object>(e, propertyName).Equals(value)),
            ComparisonType.GreaterThan => query.Where(e => EF.Property<IComparable>(e, propertyName).CompareTo(value) > 0),
            ComparisonType.LessThan => query.Where(e => EF.Property<IComparable>(e, propertyName).CompareTo(value) < 0),
            ComparisonType.Contains => query.Where(e => EF.Functions.Like(EF.Property<string>(e, propertyName), $"%{value}%")),
            _ => throw new NotSupportedException($"comparisonType {criterion.comparisonType} is not supported for EFCore filtering.")
        };
    }

    public static IQueryable<T> ApplyCriteria(IQueryable<T> query, CriterionCollection criteria, LinqQueryableExtensions.FilterType filterType)
    {
        return filterType == LinqQueryableExtensions.FilterType.Linq
            // Do not simplify.  Use the explicit naming to avoid using the EF library on a pure C# LINQ query.
            ? LinqQueryableExtensions.ApplyCriteria(query, criteria, filterType)
            : criteria.Aggregate(query, (current, criterion) => ApplyCriterion(current, criterion, filterType));
    }

}