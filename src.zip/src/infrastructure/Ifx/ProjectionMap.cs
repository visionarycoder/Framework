﻿namespace Wsdot.Idl.Ifx;

public class ProjectionMap : IProjectionMap
{

    public Dictionary<Type, ProjectionMapEntry> Projections { get; } = new();

    /// <summary>
    /// Adds a mapping between a contract type and an entity type, along with the associated query.
    /// </summary>
    /// <typeparam name="T">The type of the contract.</typeparam>
    /// <typeparam name="TU">The type of the entity.</typeparam>
    /// <param name="query">The query representing the data source for the entity type.</param>
    /// <returns>The current instance of <see cref="IProjectionMap"/> to allow method chaining.</returns>
    public IProjectionMap AddMapping<T, TU>(IQueryable query)
    {
        Projections.Add(typeof(T), new ProjectionMapEntry
        {
            EntityType = typeof(TU),
            Query = query
        });
        return this;
    }
    
    public IProjectionMap AddMapping(Type contractType, Type entityType, IQueryable query)
    {
        Projections.Add(contractType, new ProjectionMapEntry
        {
            EntityType = entityType,
            Query = query
        });
        return this;
    }

}
