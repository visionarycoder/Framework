﻿namespace Wsdot.Idl.Ifx;

public class ProjectionMapEntry
{
    public Type EntityType { get; set; } = typeof(object);
    public required IQueryable Query { get; set; }
}

