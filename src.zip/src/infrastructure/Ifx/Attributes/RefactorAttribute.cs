﻿namespace Wsdot.Idl.Ifx.Attributes;

/// <summary>
/// Marks code that needs attention. Supports optional submitter and action type for analyzers and tooling.
/// </summary>
[AttributeUsage(AttributeTargets.All, AllowMultiple = true, Inherited = false)]
public sealed class RefactorAttribute(string reason, string submitter = "Undefined", RefactorAttribute.RefactoringAction action = RefactorAttribute.RefactoringAction.General) : Attribute
{
    /// <summary>Short reason describing why this code needs attention.</summary>
    public string Reason { get; } = reason;

    /// <summary>Optional submitter/owner requesting the refactor.</summary>
    public string? Submitter { get; } = submitter;

    /// <summary>Optional action type/category.</summary>
    public RefactoringAction Action { get; } = action;

    public RefactorAttribute(string reason, string submitter)
        : this(reason, submitter, action: RefactoringAction.General)
    {
    }

    /// <summary>
    /// Categories for refactor requests. Values are stable for analyzer lookup.
    /// </summary>
    [Flags]
    public enum RefactoringAction
    {
        General = 1 << 0,
        CodeSmells = 1 << 1,
        SingleResponsibilityPrincipleViolation = 1 << 2,
        DoNotRepeatYourselfViolation = 1 << 3,
        AddTests = 1 << 4,
        Performance = 1 << 5,
        Security = 1 << 6,
        Documentation = 1 << 7,
        Simplify = 1 << 8,
        Rename = 1 << 9,
        Remove = 1 << 10,

    }
}