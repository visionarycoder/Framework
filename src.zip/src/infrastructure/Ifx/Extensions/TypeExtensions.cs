﻿using System;
using System.Reflection;

namespace Wsdot.Idl.Ifx.Extensions;

public static class TypeExtensions
{

    /// <summary>
    /// Given a constants class, this extension method will collect all constant property names associated with a given Type.  This was made an extension method
    /// to prevent duplicated code.
    /// </summary>
    /// <param name="type"></param>
    /// <returns></returns>
    public static IReadOnlyList<string> AllConstantNames(this Type type)
    {
        return type.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)
            .Where(constant => constant is { IsLiteral: true, IsInitOnly: false })
            .Select(constant => constant.Name)
            .ToList();
    }

    /// <summary>
    /// Given a constants class, this extension method will collect all constant property names associated with a given Type.  This was made an extension method
    /// to prevent duplicated code.
    /// </summary>
    /// <param name="type"></param>
    /// <returns></returns>
    public static IReadOnlyList<string> AllConstantValues(this Type type)
    {
        return type.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.FlattenHierarchy)
            .Where(constant => constant is { IsLiteral: true, IsInitOnly: false })
            .Select(constant => (string) constant.GetValue(null)!)
            .ToList();
    }

}