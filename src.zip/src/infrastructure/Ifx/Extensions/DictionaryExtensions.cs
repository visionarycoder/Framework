﻿namespace Wsdot.Idl.Ifx.Extensions;

public static class DictionaryExtensions
{
    public static bool TryGetKeyByValue<TKey, TValue>(this IDictionary<TKey, TValue> dict, TValue value, out TKey key, IEqualityComparer<TValue>? comparer = null)
    {
        ArgumentNullException.ThrowIfNull(dict);
        comparer ??= EqualityComparer<TValue>.Default;
        foreach (var kvp in dict)
        {
            if (!comparer.Equals(kvp.Value, value))
            {
                continue;
            }
            key = kvp.Key;
            return true;
        }
        key = default!;
        return false;
    }

    public static IEnumerable<TKey> GetKeysByValue<TKey, TValue>(this IDictionary<TKey, TValue> dict, TValue value, IEqualityComparer<TValue>? comparer = null)
    {
        ArgumentNullException.ThrowIfNull(dict);
        comparer ??= EqualityComparer<TValue>.Default;
        foreach (var kvp in dict)
        {
            if (!comparer.Equals(kvp.Value, value))
            {
                continue;
            }
            yield return kvp.Key;
        }
    }
}