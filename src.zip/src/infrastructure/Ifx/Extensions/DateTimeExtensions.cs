﻿#pragma warning disable ClassMethodMissingInterface
#pragma warning disable DerivedClasses
namespace Wsdot.Idl.Ifx.Extensions;

/// <summary>
/// Provides extension methods for working with <see cref="DateTime"/> values.
/// </summary>
/// <remarks>
/// All methods are pure (no side effects) and return new <see cref="DateTime"/> instances.
/// Unless otherwise noted, the <see cref="DateTime.Kind"/> and time-of-day (including sub‑second precision)
/// are preserved where it is semantically appropriate.
/// </remarks>
public static class DateTimeExtensions
{
    /// <summary>
    /// Gets the first occurrence of the specified <paramref name="dayOfWeek"/> that is
    /// either the same as the current date's day-of-week or later in the same
    /// Sunday‑to‑Saturday week.
    /// </summary>
    /// <param name="input">The source date.</param>
    /// <param name="dayOfWeek">
    /// The desired <see cref="System.DayOfWeek"/> (defaults to <see cref="DayOfWeek.Sunday"/>).
    /// </param>
    /// <returns>
    /// A date (with the time component truncated to midnight) that is either:
    /// <list type="bullet">
    ///   <item><description>The same day if <paramref name="input"/> already falls on <paramref name="dayOfWeek"/>.</description></item>
    ///   <item><description>A later day in the same week (no week rollover) if the target day is after the input's day-of-week.</description></item>
    ///   <item><description>An earlier day in the same week if the target day is before the input's day-of-week.</description></item>
    /// </list>
    /// </returns>
    /// <remarks>
    /// Despite the name, this method does not advance into the *next* week; it normalizes
    /// within the current week. If you need the *next* future occurrence (always strictly after
    /// <paramref name="input"/> when not already that day), implement a different helper.
    /// </remarks>
    /// <example>
    /// Given a Wednesday (DayOfWeek.Wednesday):
    /// - dayOfWeek = Friday  -> returns that week's Friday
    /// - dayOfWeek = Monday  -> returns that week's Monday (earlier date)
    /// - dayOfWeek = Wednesday -> returns the same date (midnight)
    /// </example>
    public static DateTime GetProceedingWeekday(this DateTime input, DayOfWeek dayOfWeek = DayOfWeek.Sunday)
    {
        var offset = (int)dayOfWeek - (int)input.DayOfWeek;
        var output = input.AddDays(offset).Date;
        return output;
    }

    /// <summary>
    /// Gets only the date component after applying a directional offset.
    /// </summary>
    /// <param name="dateTime">The starting date/time.</param>
    /// <param name="offset">The amount of time to add (future) or subtract (past).</param>
    /// <param name="relativeDateIs">
    /// Indicates whether the offset should be treated as moving into the past
    /// (<see cref="RelativeDateIs.InThePast"/>) or future (<see cref="RelativeDateIs.InTheFuture"/>).
    /// </param>
    /// <returns>The resulting date with the time set to midnight.</returns>
    /// <remarks>
    /// The sign of <paramref name="offset"/> is not inspected; direction is solely determined
    /// by <paramref name="relativeDateIs"/>. If you already encode direction in the
    /// <paramref name="offset"/> (e.g., negative values), prefer normalizing to a single convention.
    /// </remarks>
    /// <example>
    /// dateTime = 2025-09-23 14:30, offset = 2.00:00:00, InThePast  -> 2025-09-21
    /// dateTime = 2025-09-23 14:30, offset = 2.00:00:00, InTheFuture -> 2025-09-25
    /// </example>
    public static DateTime GetDateOnly(this DateTime dateTime, TimeSpan offset, RelativeDateIs relativeDateIs = RelativeDateIs.InThePast)
    {
        var offsetDateTime = relativeDateIs == RelativeDateIs.InThePast
            ? dateTime.Subtract(offset)
            : dateTime.Add(offset);
        var dateOnly = offsetDateTime.Date;
        return dateOnly;
    }

    /// <summary>
    /// Indicates relative temporal direction when computing derived dates.
    /// </summary>
    public enum RelativeDateIs
    {
        /// <summary>Offset should move the date into the past.</summary>
        InThePast,

        /// <summary>Offset should move the date into the future.</summary>
        InTheFuture
    }

    /// <summary>
    /// Converts a calendar date to its corresponding fiscal year.
    /// </summary>
    /// <param name="date">The calendar date.</param>
    /// <returns>
    /// The fiscal year number. If the month is earlier than
    /// <see cref="Constants.FIRST_MONTH_OF_FISCAL_YEAR"/>, the fiscal year equals the calendar year;
    /// otherwise it is the next calendar year.
    /// </returns>
    /// <remarks>
    /// Assumes a fiscal year that starts in <see cref="Constants.FIRST_MONTH_OF_FISCAL_YEAR"/> and
    /// runs continuously for 12 months. No leap-year specific adjustments are required.
    /// </remarks>
    /// <example>
    /// If FIRST_MONTH_OF_FISCAL_YEAR = 7 (July):
    /// - 2025-06-30 -> 2025
    /// - 2025-07-01 -> 2026
    /// </example>
    public static int AsFiscalYear(this DateTime date)
    {
        return date.Month < Constants.FIRST_MONTH_OF_FISCAL_YEAR ? date.Year : date.Year + 1;
    }

    /// <summary>
    /// Returns a <see cref="DateTime"/> representing the last calendar day of the month of the input,
    /// preserving the original time-of-day (including sub-millisecond ticks) and <see cref="DateTime.Kind"/>.
    /// </summary>
    /// <param name="date">The input date.</param>
    /// <returns>The same month’s last day with the original time component.</returns>
    /// <remarks>
    /// Implementation uses <see cref="DateTime.AddDays(double)"/> to preserve full tick precision.
    /// </remarks>
    /// <example>
    /// 2025-02-10 08:15:30.123 -> 2025-02-28 08:15:30.123 (non-leap year)
    /// 2024-02-10 08:15:30.123 -> 2024-02-29 08:15:30.123 (leap year)
    /// </example>
    public static DateTime LastDayOfMonth(this DateTime date)
    {
        var daysInMonth = DateTime.DaysInMonth(date.Year, date.Month);
        return date.AddDays(daysInMonth - date.Day);
    }
}