﻿// ReSharper disable ConvertIfStatementToReturnStatement
#pragma warning disable ClassMethodMissingInterface
#pragma warning disable DerivedClasses
namespace Wsdot.Idl.Ifx.Extensions;

public static class CollectionExtensions
{
    public static bool IsNullOrEmpty<T>(this ICollection<T>? collection)
    {
        return collection is not null && collection.Count == 0 && collection.All(i => i is not null);
    }
}