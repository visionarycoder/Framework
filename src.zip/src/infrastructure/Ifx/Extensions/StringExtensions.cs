﻿using System.Globalization;

namespace Wsdot.Idl.Ifx.Extensions;

public static class StringExtensions
{

    public static IEnumerable<string> SplitByNewLineChars(this string toSplit)
    {

        if (string.IsNullOrWhiteSpace(toSplit))
        {
            return new List<string>();
        }

        return toSplit.Split(["\r\n", "\n\r", "\n", "\r"], StringSplitOptions.None);

    }

    public static string ReplaceRange(this string input, int startIndex, string replacement)
    {

        ArgumentException.ThrowIfNullOrWhiteSpace(input);

        if (startIndex < 0 || startIndex > input.Length)
        {
            throw new ArgumentOutOfRangeException(nameof(startIndex));
        }

        if (startIndex + replacement.Length > input.Length)
        {
            throw new ArgumentOutOfRangeException(nameof(startIndex));
        }

        return $"{input[..startIndex]}{replacement}{input[(startIndex + replacement.Length)..]}";
    }

    public static string As4DigitYear(this string inputYear)
    {
        var trimmedInputYear = inputYear.Trim();

        switch (trimmedInputYear.Length)
        {
            case 2:
                break;
            case 4:
                return trimmedInputYear;
            default:
                throw new ArgumentException("Input must be a 2-digit or 4-digit year.");
        }

        if (!int.TryParse(trimmedInputYear, out var year))
        {
            throw new ArgumentException($"Unable to parse two digit year: {trimmedInputYear}");
        }

        var currentYear = DateTime.Now.Year;
        var currentCentury = currentYear / 100;
        var fullYear = (currentCentury * 100) + year;

        //in the case that fullYear is more than a century behind the current year, add a century.
        //we do this because we converted from a 2-digit date and need to correct the century in some
        //cases.
        if (fullYear < currentYear - 100)
        {
            fullYear += 100;
        }

        return fullYear.ToString(CultureInfo.InvariantCulture);
    }
}