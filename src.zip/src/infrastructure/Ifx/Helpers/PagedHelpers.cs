﻿using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Helpers;

public static class PagedHelpers
{
    public static int PageCount(this Paging source) => source.Take is > 0
        ? (int) Math.Ceiling((double)source.Skip / source.Take.Value)
        : 0;
    public static bool HasPreviousPage(this Paging source) => source.Skip > 0;
    public static bool HasNextPage(this Paging source, int totalCount) => (source.Skip + source.Take) < totalCount;
    public static int PageSize(this Paging source) => source.Take ?? 0;
    public static int PageIndex(this Paging source) => source.Skip / (source.Take ?? 1);
    public static Paged ToPaged(this Paging source, int totalItemCount) => new(PageNumber: source.PageCount(), ItemCount: source.PageSize(), TotalItemCount: totalItemCount);

}