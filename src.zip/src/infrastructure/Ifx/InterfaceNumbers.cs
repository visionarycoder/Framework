﻿/*
 * Copyright (c) 2025 WSDOT.
 */

using Wsdot.Idl.Ifx.Extensions;

namespace Wsdot.Idl.Ifx;

/// <summary>
/// Encapsulates the constants that specify the different interface numbers
/// handled by the system.
/// </summary>
public class InterfaceNumbers
{
    /// <summary>
    /// Represents SPORT 2025 interface.
    /// </summary>
    public const string INTERFACE_2025 = "2025";

    /// <summary>
    /// Represents CAPS 2029 interface.
    /// </summary>
    public const string INTERFACE_2029 = "2029";

    /// <summary>
    /// Represents CAFM 2037 interface.
    /// </summary>
    public const string INTERFACE_2037 = "2037";

    /// <summary>
    /// Represents CAPS 2040 interface.
    /// </summary>
    public const string INTERFACE_2040 = "2040";

    /// <summary>
    /// Represents FEMS 2042 interface.
    /// </summary>
    public const string INTERFACE_2042 = "2042";

    /// <summary>
    /// Represents FEMS 2044 interface.
    /// </summary>
    public const string INTERFACE_2044 = "2044";

    /// <summary>
    /// Represents FEMS 2066 interface.
    /// </summary>
    public const string INTERFACE_2066 = "2066";

    /// <summary>
    /// Represents FEMS 2067 interface.
    /// </summary>
    public const string INTERFACE_2067 = "2067";

    /// <summary>
    /// Represents FEMS 2068 interface.
    /// </summary>
    public const string INTERFACE_2068 = "2068";

    /// <summary>
    /// Represents FEMS 2069 interface.
    /// </summary>
    public const string INTERFACE_2069 = "2069";

    /// <summary>
    /// Represents FEMS 2070 interface.
    /// </summary>
    public const string INTERFACE_2070 = "2070";

    /// <summary>
    /// Represents DOTtime Integration 2083 interface.
    /// </summary>
    public const string INTERFACE_2083 = "2083";

    /// <summary>
    /// Represents Crosswalk DOTtime NPE File 2104 interface.
    /// </summary>
    public const string INTERFACE_2104 = "2104";

    /// <summary>
    /// Represents FEMS 2112 interface.
    /// </summary>
    public const string INTERFACE_2112 = "2112";

    /// <summary>
    /// Represents HATS 2113 interface.
    /// </summary>
    public const string INTERFACE_2113 = "2113";

    /// <summary>
    /// Represents Capital Connect 2114 interface.
    /// </summary>
    public const string INTERFACE_2114 = "2114";

    /// <summary>
    /// Represents Consumable Inventory 2118 interface.
    /// </summary>
    public const string INTERFACE_2118 = "2118";

    /// <summary>
    /// Represents PCMS 2119 interface.
    /// </summary>
    public const string INTERFACE_2119 = "2119";

    /// <summary>
    /// Represents Consumable Inventory 2120 interface.
    /// </summary>
    public const string INTERFACE_2120 = "2120";

    /// <summary>
    /// Represents DOTtime 2126 interface.
    /// </summary>
    public const string INTERFACE_2126 = "2126";

    /// <summary>
    /// Represents DOTtime 2127 interface.
    /// </summary>
    public const string INTERFACE_2127 = "2127";

    /// <summary>
    /// Represents DOTtime 2129 interface.
    /// </summary>
    public const string INTERFACE_2129 = "2129";

    /// <summary>
    /// Represents DOTtime 2130 interface.
    /// </summary>
    public const string INTERFACE_2130 = "2130";

    /// <summary>
    /// Represents DOTtime 2131 interface.
    /// </summary>
    public const string INTERFACE_2131 = "2131";

    /// <summary>
    /// Represents B2GNow 2136 interface.
    /// </summary>
    public const string INTERFACE_2136 = "2136";

    /// <summary>
    /// Represents Start Sweeper 2137 interface.
    /// </summary>
    public const string INTERFACE_2137 = "2137";

    /// <summary>
    /// Represents Engineering Splits interface.
    /// </summary>
    public const string INTERFACE_2139 = "2139";


    /// <summary>
    /// Collection of all File Type constant names.
    /// </summary>
    public static readonly IReadOnlyList<string> AllConstantNames = typeof(InterfaceNumbers).AllConstantNames();

    /// <summary>
    /// Collection of all File Type constant values.
    /// </summary>
    public static readonly IReadOnlyList<string> AllConstantValues = typeof(InterfaceNumbers).AllConstantValues();

}