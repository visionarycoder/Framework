﻿namespace Wsdot.Idl.Ifx.Enums;

public enum DateIs
{
    NullOrEmpty = 0,
    Today,
    InThePast,
    TodayOrInThePast,
    InTheFuture,
    TodayOrInTheFuture
}
