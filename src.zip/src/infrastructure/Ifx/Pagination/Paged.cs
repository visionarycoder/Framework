﻿namespace Wsdot.Idl.Ifx.Pagination;

public record Paged(int PageNumber = 1, int ItemCount = 0, int TotalItemCount = 0);