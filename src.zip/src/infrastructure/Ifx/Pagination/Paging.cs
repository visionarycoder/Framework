﻿namespace Wsdot.Idl.Ifx.Pagination;

public record Paging(int Skip = 0, int? Take = null)
{
    public static Paging Empty { get; } = new();
}