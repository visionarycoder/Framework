﻿using Wsdot.Idl.Ifx.Extensions;

namespace Wsdot.Idl.Ifx;

public class RunTypes
{

    public const string OnDemand = "ON-DEMAND";
    public const string RunSchedules = "RUN-SCHEDULES";

    /// <summary>
    /// Collection of all File Type constant names.
    /// </summary>
    public static readonly IReadOnlyList<string> AllConstantNames = typeof(RunTypes).AllConstantNames();

    /// <summary>
    /// Collection of all File Type constant values.
    /// </summary>
    public static readonly IReadOnlyList<string> AllConstantValues = typeof(RunTypes).AllConstantValues();

}
