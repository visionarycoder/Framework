﻿global using System;
global using System.Collections.Generic;
global using System.Runtime.CompilerServices;
global using System.Threading.Tasks;
global using LanguageExt;
global using LanguageExt.ClassInstances;
global using LanguageExt.Common;
global using LanguageExt.Effects;
global using LanguageExt.Pipes;
global using LanguageExt.Pretty;
global using LanguageExt.TypeClasses;
global using static LanguageExt.Prelude;

[assembly: InternalsVisibleTo("vc.Ifx.UnitTests")]
