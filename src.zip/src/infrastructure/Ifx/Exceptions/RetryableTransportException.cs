﻿namespace Wsdot.Idl.Ifx.Exceptions;

public class RetryableTransportException(string message, Exception? inner = null) : Exception(message, inner);