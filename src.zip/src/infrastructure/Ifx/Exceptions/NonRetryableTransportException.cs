﻿namespace Wsdot.Idl.Ifx.Exceptions;

public class NonRetryableTransportException(string message, Exception? inner = null) : Exception(message, inner);