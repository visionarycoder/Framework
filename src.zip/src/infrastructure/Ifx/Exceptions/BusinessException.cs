﻿namespace Wsdot.Idl.Ifx.Exceptions;

public class BusinessException(string message) : Exception(message);