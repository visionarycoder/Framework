﻿namespace Wsdot.Idl.Ifx;

public interface IProjectionMap
{
    Dictionary<Type, ProjectionMapEntry> Projections { get; }
    IProjectionMap AddMapping<T, TU>(IQueryable query);
    IProjectionMap AddMapping(Type contractType, Type entityType, IQueryable query);
}