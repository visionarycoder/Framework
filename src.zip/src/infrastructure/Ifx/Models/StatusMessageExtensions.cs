﻿namespace Wsdot.Idl.Ifx.Models;

public static class StatusMessageExtensions
{
    public static string ErrorMessageFormat(this StatusMessage statusMessage, string workOrderNumber)
    {
        return $"Work Order: {workOrderNumber} {statusMessage.Code}: {statusMessage.Message}";
    }
}