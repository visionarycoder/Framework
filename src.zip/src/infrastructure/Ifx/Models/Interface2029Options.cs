﻿namespace Wsdot.Idl.Ifx.Models;

public class Interface2029Options
{
    public Interface2029Input Input { get; set; } = new();
    public Interface2029Output Output { get; set; } = new();
}