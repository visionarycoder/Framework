﻿/*
 * Copyright (c) 2025 WSDOT.
 */

namespace Wsdot.Idl.Ifx.Models;

/// <summary>
/// Represents an IDL interface.
/// </summary>
public record IdlInterface
{
    /// <summary>
    /// The interface unique ID or number, e.g., 2025.
    /// </summary>
    public string? InterfaceId { get; set; }

    /// <summary>
    /// The interface type, e.g., C_SHARP or SYNAPSE
    /// </summary>
    public string? InterfaceType { get; set; }
}