﻿namespace Wsdot.Idl.Ifx.Models;

public class Interface2029Input
{
    public string? DirectoryPath { get; set; }
    public string? HeaderFileName { get; set; }

    public string? DetailFileName { get; set; }
}