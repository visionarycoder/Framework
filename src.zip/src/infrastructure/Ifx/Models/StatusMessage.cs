﻿namespace Wsdot.Idl.Ifx.Models;

public sealed record StatusMessage(string Code, string Message);