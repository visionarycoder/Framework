﻿namespace Wsdot.Idl.Ifx.Models;

public class Interface2029Output
{
    public string? DirectoryPath { get; set; }
    public string? FileNamePattern { get; set; }
}