﻿namespace Wsdot.Idl.Ifx.Models;

public record TimePeriod(DateTime Start, DateTime End)
{

    public static TimePeriod Create(DateTime start, DateTime end) => new(start, end);

    public static implicit operator DateTime(TimePeriod timePeriod) => timePeriod.Start;
    public static implicit operator (DateTime Start, DateTime End)(TimePeriod timePeriod) => (timePeriod.Start, timePeriod.End);
    public static implicit operator TimePeriod((DateTime Start, DateTime End) tuple) => new(tuple.Start, tuple.End);

    public TimeSpan Duration => End - Start;

    public bool IsActive(DateTime currentDate) => currentDate >= Start && currentDate <= End;
    public bool IsPast(DateTime currentDate) => currentDate > End;
    public bool IsOverlapping(TimePeriod other) => Start < other.End && End > other.Start;
    public bool IsFuture(DateTime currentDate) => currentDate < Start;
    public bool IsCurrent(DateTime currentDate) => IsActive(currentDate) || IsFuture(currentDate);

}