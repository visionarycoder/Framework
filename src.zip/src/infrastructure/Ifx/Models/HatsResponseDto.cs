﻿using System.ComponentModel.DataAnnotations;

namespace Wsdot.Idl.Ifx.Models;

//[Obsolete] public class HatsResponseDto
//{
//    [Required] public string? ErrorCode { get; set; }
//    public string? StatusMessage { get; set; }
//    public decimal? TotalToDateExpenditures { get; set; }
//}