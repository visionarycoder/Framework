﻿namespace Wsdot.Idl.Ifx.Models;

//[Obsolete] public class PcmsRequestDto
//{
//    public string? DepartmentCode { get; set; }
//    public string? TaskOrder { get; set; }
//    public DateTime ExpenditureDate { get; set; }
//    public string? PhaseCode { get; set; }
//    public string? FunctionCode { get; set; }
//    public string? ObjectCode { get; set; }
//    public string? UnitCode { get; set; }
//    public string? SubUnitCode { get; set; }
//    public string? ActivityCode { get; set; }
//    public string? FundCode { get; set; }
//    public string? AppropriationCode { get; set; }
//    public string? ProgramCode { get; set; }
//    public string? LocationCode { get; set; }
//}