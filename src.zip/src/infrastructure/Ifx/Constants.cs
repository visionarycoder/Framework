﻿/*
 * Copyright (c) 2025 WSDOT.
 */

namespace Wsdot.Idl.Ifx;

/// <summary>
/// Global constants for the IDL system.
/// </summary>
public static class Constants
{
    public const float FLOATING_POINT_ERROR = 0.0000001f;

    public const string INTERFACE_TYPE_SYNAPSE_PIPELINE = "SYNAPSE";
    public const string INTERFACE_TYPE_C_SHARP = "C_SHARP";

    public const string RUN_TYPE_ON_DEMAND = "ON-DEMAND";
    public const string RUN_TYPE_RUN_SCHEDULES = "RUN-SCHEDULES";

    //Configuration for Fems 2112
    public const string I2112_FIELD_POSITIONS = "1-2,3-8,9-16,17-22,23-28,29-32,33-36,37-44,39-39,45-47";

    //Configuration for Interface 2066
    public const string I2066_FIELD_POSITIONS_LOAD = "1-1,2-2,3-6,7-10,11-16,17-20,21-24,25-26,27-28,29-29,30-30,31-35,36-36";
    public const string I2066_FIELD_POSITIONS_HEADER = "37-38,39-41,42-43,44-45,46-52,53-54,55-56,57-58,59-60,61-62,63-64,65-78,79-92,93-106,107-120,121-121";
    public const string I2066_FIELD_POSITIONS_DETAIL = "37-42,43-44,45-50,51-54,55-58,59-62,63-64,65-70,71-76,77-84,85-86,87-87,88-89,90-93,94-118,119-119," +
                                                    "120-130,131-160,161-174,175-188,189-200,201-214,215-228,229-236,237-239,240-242,243-248,249-255";

    //Configuration for Interface 2044
    public const string I2044_FIELD_POSITIONS_HEADER = "1-2,3-6,7-10,17-20,21-24,25-26,27-28,31-35,37-38,39-41,42-43,44-45,48-52,53-54,55-56,57-58,59-60,61-62,65-78,79-92";
    public const string I2044_FIELD_POSITIONS_DETAIL = "1-2,3-6,7-10,17-20,21-24,25-26,27-28,31-35,37-42,43-44,45-50,51-54,55-58,85-86,90-93,94-118,161-174,175-188";

    //July is the starting month for WSDOT fiscal year
    public const int FIRST_MONTH_OF_FISCAL_YEAR = 7;

}