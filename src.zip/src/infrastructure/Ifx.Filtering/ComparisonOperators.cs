﻿using System.Collections;

namespace Wsdot.Idl.Ifx.Filtering;

public static class ComparisonOperators
{

    public delegate bool Operation(object? left, object? right, in ComparisonContext ctx);


    private static readonly Dictionary<string, Operation> operations = new(StringComparer.OrdinalIgnoreCase)
    {
        [FilteringConstants.Comparisons.EQUALS] = EqualsOp,
        [FilteringConstants.Comparisons.EQ] = EqualsOp,

        [FilteringConstants.Comparisons.NOT_EQUALS] = NotEqualsOp,
        [FilteringConstants.Comparisons.NEQ] = NotEqualsOp,

        [FilteringConstants.Comparisons.GREATER_THAN] = GreaterThanOp,
        [FilteringConstants.Comparisons.GT] = GreaterThanOp,

        [FilteringConstants.Comparisons.LESS_THAN] = LessThanOp,
        [FilteringConstants.Comparisons.LT] = LessThanOp,

        [FilteringConstants.Comparisons.CONTAINS] = ContainsOp
    };

    public static bool TryGet(string key, out Operation func) => operations.TryGetValue(key, out func) || operations.TryGetValue(key.ToLowerInvariant(), out func);

    public static void Register(string key, Operation func) => operations[key] = func;

    // Built-ins
    private static bool EqualsOp(object? a, object? b, in ComparisonContext ctx)
    {
        if (a is string sa && b is string sb)
            return string.Equals(sa, sb, ctx.StringComparison);

        if (a is IComparable comparable && b is not null)
            return comparable.CompareTo(b) == 0;

        return Equals(a, b);
    }

    private static bool NotEqualsOp(object? a, object? b, in ComparisonContext ctx) => !EqualsOp(a, b, ctx);

    private static bool GreaterThanOp(object? a, object? b, in ComparisonContext _) => CompareComparable(a, b) > 0;

    private static bool LessThanOp(object? a, object? b, in ComparisonContext _) => CompareComparable(a, b) < 0;

    private static bool ContainsOp(object? a, object? b, in ComparisonContext ctx)
    {

        if (a is string sa && b is string sb)
        {
            var compareInfo = ctx.EffectiveCulture.CompareInfo;
            return compareInfo.IndexOf(sa, sb, ctx.CompareOptions) >= 0;
        }

        if (a is IEnumerable enumerable)
        {
            return enumerable.Cast<object?>().Contains(b);
        }

        return false;

    }

    private static int CompareComparable(object? a, object? b)
    {

        switch (a)
        {
            case null when b is null: return 0;
            case null: return -1;
        }
        if (a is IComparable cmp)
            return cmp.CompareTo(b);

        if (b is null)
            return 1;
        throw new InvalidOperationException($"Type '{a.GetType()}' is not comparable.");

    }

}