﻿namespace Wsdot.Idl.Ifx.Filtering;

public class CriterionCollection : List<Criterion> { }