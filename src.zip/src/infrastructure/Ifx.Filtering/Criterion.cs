﻿namespace Wsdot.Idl.Ifx.Filtering;

public readonly record struct Criterion(string PropertyName, object? PropertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison StringComparison = StringComparison.CurrentCulture);