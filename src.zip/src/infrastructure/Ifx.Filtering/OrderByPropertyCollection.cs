﻿namespace Wsdot.Idl.Ifx.Filtering;

public class OrderByPropertyCollection : List<OrderByProperty> { }