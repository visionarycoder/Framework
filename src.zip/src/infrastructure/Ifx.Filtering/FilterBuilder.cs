﻿using System.ComponentModel;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering;

public class FilterBuilder
{

    private readonly Filter filter = new();

    public static FilterBuilder Create() => new();

    public FilterBuilder WithCriterion(string propertyName, object? value, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        filter.Criteria.Add(new Criterion(propertyName, value, comparisonType, stringComparison));
        return this;
    }

    public FilterBuilder WithCriterion(Criterion criterion)
    {
        filter.Criteria.Add(criterion);
        return this;
    }

    public FilterBuilder WithOrderBy(string propertyName, ListSortDirection direction = ListSortDirection.Ascending)
    {
        filter.OrderBy.Add(new OrderByProperty(propertyName, direction));
        return this;
    }

    public FilterBuilder WithOrderBy(OrderByProperty orderByProperty)
    {
        filter.OrderBy.Add(orderByProperty);
        return this;
    }

    public FilterBuilder WithPaging(int skip = 0, int? take = null)
    {
        filter.Paging = new Paging(skip, take);
        return this;
    }

    public FilterBuilder WithPaging(Paging paging)
    {
        filter.Paging = paging;
        return this;
    }

    public Filter Build() => filter;

}