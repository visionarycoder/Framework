﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering;

public class Filter<T> : Filter
{

    public Filter()
    {
    }

    public Filter(CriterionCollection criteria, OrderByPropertyCollection orderBy, Paging paging)
        : base(criteria, orderBy, paging)
    {
    }

}