﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace Wsdot.Idl.Ifx.Filtering;

public enum ComparisonType
{

    [Description(FilteringConstants.Comparisons.EQUALS)]
    [EnumMember(Value = FilteringConstants.Comparisons.EQUALS)]
    Equals = 1,

    [Description(FilteringConstants.Comparisons.EQ)]
    [EnumMember(Value = FilteringConstants.Comparisons.EQ)]
    Eq = Equals,

    [Description(FilteringConstants.Comparisons.NOT_EQUALS)]
    [EnumMember(Value = FilteringConstants.Comparisons.NOT_EQUALS)]
    NotEquals = 2,

    [Description(FilteringConstants.Comparisons.NEQ)]
    [EnumMember(Value = FilteringConstants.Comparisons.NEQ)]
    Neq = NotEquals,

    [Description(FilteringConstants.Comparisons.GREATER_THAN)]
    [EnumMember(Value = FilteringConstants.Comparisons.GREATER_THAN)]
    GreaterThan = 3,

    [Description(FilteringConstants.Comparisons.GT)]
    [EnumMember(Value = FilteringConstants.Comparisons.GT)]
    Gt = GreaterThan,

    [Description(FilteringConstants.Comparisons.LESS_THAN)]
    [EnumMember(Value = FilteringConstants.Comparisons.LESS_THAN)]
    LessThan = 4,

    [Description(FilteringConstants.Comparisons.LT)]
    [EnumMember(Value = FilteringConstants.Comparisons.LT)]
    Lt,

    [Description(FilteringConstants.Comparisons.CONTAINS)]
    [EnumMember(Value = FilteringConstants.Comparisons.CONTAINS)]
    Contains
}