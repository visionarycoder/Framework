﻿using System.ComponentModel;
using System.Linq.Expressions;
using System.Reflection;

using Wsdot.Idl.Ifx.Extensions;
using Wsdot.Idl.Ifx.Filtering.Exceptions;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering.Extensions;

/// <summary>
/// Extension methods that apply dynamic filtering, ordering and paging to <see cref="IQueryable{T}"/> sources
/// based on IFX filtering primitives (Filter, Criterion, OrderByProperty, Paging).
/// </summary>
public static class QueryableExtensions
{
    // Get MethodInfo references for ToString, ToLower, and CONTAINS
    private static readonly MethodInfo toStringMethod = typeof(object).GetMethod(FilteringConstants.METHOD_NAME_TO_STRING, Type.EmptyTypes)!;
    private static readonly MethodInfo toLowerMethod = typeof(string).GetMethod(FilteringConstants.METHOD_NAME_TO_LOWER, Type.EmptyTypes)!;
    private static readonly MethodInfo containsMethod = typeof(string).GetMethod(FilteringConstants.METHOD_NAME_CONTAINS, [typeof(string)])!;

    /// <summary>
    /// Applies all components of a generic <see cref="Filter{T}"/> (criteria, ordering, paging) to the query.
    /// Skips processing if the filter is empty.
    /// </summary>
    public static IQueryable<T> ApplyFilter<T>(this IQueryable<T> query, Filter<T> filter, FilterType filterType = FilterType.Linq)
    {
        if (filter.IsEmpty())
        {
            return query;
        }
        query = query.ApplyCriteria(filter.Criteria, filterType);
        query = query.ApplyOrdering(filter.OrderBy);
        query = query.ApplyPaging(filter.Paging);
        return query;
    }

    /// <summary>
    /// Applies the supplied <see cref="CriterionCollection"/> to the query, combining predicates with logical AND.
    /// </summary>
    /// <exception cref="NotSupportedException">Thrown when the specified <paramref name="filterType"/> is not supported.</exception>
    public static IQueryable<T> ApplyCriteria<T>(this IQueryable<T> query, CriterionCollection criteria, FilterType filterType)
    {
        if (filterType != FilterType.Linq)
        {
            throw new NotSupportedException($"FilterType {filterType} is not supported.");
        }
        return criteria.Aggregate(query, (current, criterion) => current.ApplyCriterion(criterion, filterType));
    }

    /// <summary>
    /// Applies a single <see cref="Criterion"/> (a predicate) to the query.
    /// </summary>
    /// <exception cref="NotSupportedException">Thrown when the specified <paramref name="filterType"/> is not supported.</exception>
    public static IQueryable<T> ApplyCriterion<T>(this IQueryable<T> query, Criterion criterion, FilterType filterType)
    {
        if (filterType != FilterType.Linq)
        {
            throw new NotSupportedException($"FilterType {filterType} is not supported.");
        }
        InvalidCriterionException.ThrowIfNullOrWhitespace(criterion.PropertyName);
        var predicate = BuildPredicate<T>(criterion);
        return query.Where(predicate);
    }

    /// <summary>
    /// Applies ordering to the query using the first element as OrderBy and remaining elements as ThenBy clauses.
    /// No operation is performed if the collection is empty.
    /// </summary>
    public static IQueryable<T> ApplyOrdering<T>(this IQueryable<T> query, OrderByPropertyCollection orderBy)
    {
        for (var i = 0; i < orderBy.Count; i++)
        {
            query = i == 0
                ? query.ApplyOrderBy(orderBy[0])
                : query.ApplyThenBy(orderBy[i]);
        }
        return query;
    }

    /// <summary>
    /// Applies a primary ordering (OrderBy / OrderByDescending) to the query for the given property.
    /// </summary>
    public static IQueryable<T> ApplyOrderBy<T>(this IQueryable<T> query, OrderByProperty orderByProperty)
    {
        var parameter = Expression.Parameter(typeof(T), "e");
        var property = Expression.Property(parameter, orderByProperty.PropertyName);
        var lambda = Expression.Lambda(property, parameter);
        var methodName = orderByProperty.SortDirection == ListSortDirection.Ascending
            ? FilteringConstants.ORDER_BY
            : FilteringConstants.ORDER_BY_DESCENDING;
        var resultExpression = Expression.Call(typeof(Queryable), methodName, [typeof(T), property.Type], query.Expression, Expression.Quote(lambda));
        return query.Provider.CreateQuery<T>(resultExpression);
    }

    /// <summary>
    /// Applies a subsequent ordering (ThenBy / ThenByDescending) to an already ordered query.
    /// </summary>
    public static IQueryable<T> ApplyThenBy<T>(this IQueryable<T> query, OrderByProperty orderByProperty)
    {
        var parameter = Expression.Parameter(typeof(T), FilteringConstants.EXPRESSION_PARAMETER);
        var property = Expression.Property(parameter, orderByProperty.PropertyName);
        var lambda = Expression.Lambda(property, parameter);
        var methodName = orderByProperty.SortDirection == ListSortDirection.Ascending
            ? FilteringConstants.THEN_BY
            : FilteringConstants.THEN_BY_DESCENDING;
        var resultExpression = Expression.Call(typeof(Queryable), methodName, [typeof(T), property.Type], query.Expression, Expression.Quote(lambda));
        return query.Provider.CreateQuery<T>(resultExpression);
    }

    /// <summary>
    /// Applies skip/take paging semantics based on a <see cref="Paging"/> value:
    /// Skip only, Take only, both, or none. Returns the original query if paging is empty.
    /// </summary>
    public static IQueryable<T> ApplyPaging<T>(this IQueryable<T> query, Paging paging)
    {
        if (paging.IsEmpty())
        {
            return query;
        }

        if (paging.HasDefinedSkip() && !paging.HasDefinedTake())
        {
            return query.Skip(paging.Skip);
        }

        if (paging.HasDefinedSkip() && paging.HasDefinedTake())
        {
            return query.Skip(paging.Skip).Take(paging.Take!.Value);
        }

        return paging.HasDefinedTake()
            ? query.Skip(0).Take(paging.Take!.Value)
            : query;
    }

    /// <summary>
    /// Builds a predicate expression for the specified criterion.
    /// </summary>
    /// <exception cref="NotSupportedException">Thrown when the comparison type is unsupported.</exception>
    public static Expression<Func<T, bool>> BuildPredicate<T>(Criterion criterion)
    {

        var parameter = Expression.Parameter(typeof(T), FilteringConstants.EXPRESSION_PARAMETER);
        var property = Expression.Property(parameter, criterion.PropertyName);
        var constant = Expression.Constant(criterion.PropertyValue);

        Expression body = criterion.comparisonType switch
        {
            ComparisonType.Equals => Expression.Equal(property, constant),
            ComparisonType.NotEquals => Expression.NotEqual(property, constant),
            ComparisonType.GreaterThan => Expression.GreaterThan(property, constant),
            ComparisonType.LessThan => Expression.LessThan(property, constant),
            ComparisonType.Contains when criterion.StringComparison is StringComparison.CurrentCultureIgnoreCase or StringComparison.InvariantCultureIgnoreCase or StringComparison.OrdinalIgnoreCase => BuildCaseInsensitiveContains(property, constant),
            ComparisonType.Contains => Expression.Call(property, FilteringConstants.METHOD_NAME_CONTAINS, null, constant),
            _ => throw new NotSupportedException($"comparisonType {criterion.comparisonType} is not supported.")
        };

        return Expression.Lambda<Func<T, bool>>(body, parameter);
    }

    /// <summary>
    /// Builds a case-insensitive "Contains" expression by lowercasing both property and constant sides.
    /// </summary>
    public static MethodCallExpression BuildCaseInsensitiveContains(Expression property, Expression constant)
    {
        // Convert property to string and to lowercase
        var propertyToString = Expression.Call(property, toStringMethod);
        var propertyToLower = Expression.Call(propertyToString, toLowerMethod);

        // Convert constant to string and to lowercase
        var constantToString = Expression.Call(constant, toStringMethod);
        var constantToLower = Expression.Call(constantToString, toLowerMethod);

        // Build the "CONTAINS" call
        return Expression.Call(propertyToLower, containsMethod, constantToLower);
    }

    /// <summary>
    /// Supported filtering execution strategies.
    /// </summary>
    public enum FilterType
    {
        /// <summary>Build predicates with LINQ expression trees (default).</summary>
        Linq,
        /// <summary>Reserved for EF Core translation.  Implemented in <see cref="EFCoreQueryableExtensions"/>.</summary>
        EFCore
    }
}