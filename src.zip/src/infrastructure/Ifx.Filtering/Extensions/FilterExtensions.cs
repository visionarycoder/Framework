﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

using Wsdot.Idl.Ifx.Filtering.Exceptions;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering.Extensions;

public static class FilterExtensions
{

    #region Add
    public static bool AddCriterion(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Add(item);
    }

    public static bool Add(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Add(item);
    }

    public static bool Add(this Filter filter, Criterion item)
    {
        InvalidCriterionException.ThrowIfNullOrWhitespace(item.PropertyName);
        if (filter.Criteria.Any(c => c.PropertyName == item.PropertyName))
        {
            throw new CriterionArgumentException("Unable to add item.  Item already exists in the collection.");
        }

        filter.Criteria.Add(item);
        return true;
    }

    public static bool AddOrderBy(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Add(item);
    }

    public static bool Add(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Add(item);
    }

    public static bool Add(this Filter filter, OrderByProperty orderBy)
    {
        InvalidOrderByPropertyException.ThrowIfNullOrWhitespace(orderBy.PropertyName);
        if (filter.OrderBy.Any(c => c.PropertyName == orderBy.PropertyName))
        {
            throw new OrderByPropertyArgumentException("Unable to add item.  Item already exists in the collection.");
        }
        filter.OrderBy.Add(orderBy);
        return true;
    }

    public static bool AddPaging(this Filter filter, int skip, int? take)
    {
        var paging = new Paging(skip, take);
        return filter.Add(paging);
    }

    public static bool Add(this Filter filter, int skip, int? take)
    {
        var paging = new Paging(skip, take);
        return filter.Add(paging);
    }

    public static bool Add(this Filter filter, Paging item)
    {

        PagingOutOfRangeException.ThrowIfLessThanZero(item.Skip);
        PagingOutOfRangeException.ThrowIfLessThanZero(item.Take);
        PagingArgumentException.ThrowIfExistingNotEmpty(filter.Paging);
        if (filter.Paging == Paging.Empty)
        {
            filter.Paging = item;
            return true;
        }
        return false;

    }
    #endregion Add

    #region AddOrUpdate
    public static bool AddOrUpdateCriterion(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Update(item);
    }

    public static bool AddOrUpdate(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Update(item);
    }

    public static bool AddOrUpdate(this Filter filter, Criterion criterion)
    {
        InvalidCriterionException.ThrowIfNullOrWhitespace(criterion.PropertyName);
        return filter.Criteria.Any(c => c.PropertyName == criterion.PropertyName)
            ? filter.Update(criterion)
            : filter.Add(criterion);
    }

    public static bool AddOrUpdateOrderBy(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Update(item);
    }

    public static bool AddOrUpdate(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Update(item);
    }

    public static bool AddOrUpdate(this Filter filter, OrderByProperty orderBy)
    {
        InvalidOrderByPropertyException.ThrowIfNullOrWhitespace(orderBy.PropertyName);
        return filter.OrderBy.Any(c => c.PropertyName == orderBy.PropertyName)
            ? filter.Update(orderBy)
            : filter.Add(orderBy);
    }

    public static bool AddOrUpdatePaging(this Filter filter, int skip, int? take)
    {
        var item = new Paging(skip, take);
        return filter.AddOrUpdate(item);
    }

    public static bool AddOrUpdate(this Filter filter, int skip, int? take)
    {
        var item = new Paging(skip, take);
        return filter.AddOrUpdate(item);
    }

    public static bool AddOrUpdate(this Filter filter, Paging paging)
    {
        return (filter.Paging == Paging.Empty)
            ? filter.Add(paging)
            : filter.Update(paging);
    }
    #endregion AddOrUpdate

    #region Update
    public static bool UpdateCriterion(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Update(item);
    }

    public static bool Update(this Filter filter, string propertyName, object? propertyValue, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, propertyValue, comparisonType, stringComparison);
        return filter.Update(item);
    }

    public static bool Update(this Filter filter, Criterion criterion)
    {
        InvalidCriterionException.ThrowIfNullOrWhitespace(criterion.PropertyName);
        if (filter.Criteria.Any(c => c.PropertyName == criterion.PropertyName))
        {
            throw new CriterionOutOfRangeException("Unable to add criterion.  Item already exists in the collection.");
        }
        var matching = filter.Criteria.SingleOrDefault(c => c.PropertyName == criterion.PropertyName);
        var idx = filter.Criteria.IndexOf(matching);
        filter.Criteria.Remove(matching);
        filter.Criteria.Insert(idx, criterion);
        return true;
    }

    public static bool UpdateOrderBy(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Update(item);
    }

    public static bool Update(this Filter filter, string propertyName, ListSortDirection sortDirection = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, sortDirection);
        return filter.Update(item);
    }

    public static bool Update(this Filter filter, OrderByProperty orderBy)
    {
        InvalidOrderByPropertyException.ThrowIfNullOrWhitespace(orderBy.PropertyName);
        var matching = filter.OrderBy.SingleOrDefault(c => c.PropertyName == orderBy.PropertyName);
        if (matching is null)
        {
            throw new OrderByPropertyOutOfRangeException("Item not found");
        }
        var idx = filter.OrderBy.IndexOf(matching);
        filter.OrderBy.Remove(matching);
        filter.OrderBy.Insert(idx, orderBy);
        return true;
    }

    public static bool UpdatePaging(this Filter filter, int skip, int? take)
    {
        var paging = new Paging(skip, take);
        return filter.Update(paging);
    }

    public static bool Update(this Filter filter, int skip, int? take)
    {
        var paging = new Paging(skip, take);
        return filter.Update(paging);
    }
    
    public static bool Update(this Filter filter, Paging paging)
    {

        PagingOutOfRangeException.ThrowIfLessThanZero(paging.Skip);
        PagingOutOfRangeException.ThrowIfLessThanZero(paging.Take);
        filter.Paging = paging;
        return true;
    }
    #endregion Update

    #region Converters
    public static Filter Convert(this Filter source)
    {
        return new Filter(source.Criteria, source.OrderBy, source.Paging);
    }

    public static Filter<T> Convert<T>(this Filter source)
    {
        return new Filter<T>(source.Criteria, source.OrderBy, source.Paging);
    }

    public static Filter<TOut> Convert<TIn, TOut>(this Filter<TIn> source)
    {
        return new Filter<TOut>(source.Criteria, source.OrderBy, source.Paging);
    }
    #endregion Converters

    #region Validators
    public static ValidationResult Validate<T>(this Filter<T> filter) where T : new()
    {

        if (filter.Criteria.Count == 0 && filter.OrderBy.Count == 0)
        {
            return ValidationResult.Success!;
        }

        var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Select(p => p.Name)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var errors = filter
            .Criteria
            .Where(c => !properties.Contains(c.PropertyName))
            .Select(c => new ValidationResult($"Property '{c.PropertyName}' does not exist in type {typeof(T).Name}.", [nameof(Filter.Criteria)]))
            .Concat(filter.OrderBy.Where(o => !properties.Contains(o.PropertyName))
                .Select(o => new ValidationResult($"Property '{o.PropertyName}' does not exist in type {typeof(T).Name}.", [nameof(Filter.OrderBy)])))
            .ToList();

        return errors.Count > 0
            ? new ValidationResult($"Filter contains {errors.Count} invalid property references.", errors.SelectMany(e => e.MemberNames))
            : ValidationResult.Success!;
    }
    #endregion Validators

    public static bool IsEmpty(this Filter filter)
    {
        return filter.Criteria.Count == 0 && filter.OrderBy.Count == 0 && filter.Paging == Paging.Empty;
    }

}