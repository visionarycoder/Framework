﻿using System.ComponentModel;

namespace Wsdot.Idl.Ifx.Filtering;

public record OrderByProperty(string PropertyName, ListSortDirection SortDirection = ListSortDirection.Ascending);