﻿using System.ComponentModel;
// ReSharper disable ParameterHidesMember

namespace Wsdot.Idl.Ifx.Filtering;

public class OrderByPropertyBuilder
{

    private string propertyName = string.Empty;
    private ListSortDirection sortDirection = ListSortDirection.Ascending;

    public OrderByPropertyBuilder ForProperty(string propertyName)
    {
        this.propertyName = propertyName;
        return this;
    }

    public OrderByPropertyBuilder Ascending()
    {
        sortDirection = ListSortDirection.Ascending;
        return this;
    }

    public OrderByPropertyBuilder Descending()
    {
        sortDirection = ListSortDirection.Descending;
        return this;
    }

    public OrderByPropertyBuilder WithSortDirection(ListSortDirection sortDirection)
    {
        this.sortDirection = sortDirection;
        return this;
    }

    public OrderByProperty Build()
    {
        return new OrderByProperty(propertyName, sortDirection);
    }

}