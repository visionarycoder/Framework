﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Wsdot.Idl.Ifx.Filtering.Extensions;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering;

public class FilterBuilder<T>
{

    private readonly Filter<T> filter = new();

    public FilterBuilder<T> WithCriteria(IEnumerable<Criterion> criteria)
    {
        filter.Criteria.AddRange(criteria);
        return this;
    }

    public FilterBuilder<T> WithCriterion(string propertyName, object? value, ComparisonType comparisonType = ComparisonType.Equals, StringComparison stringComparison = StringComparison.CurrentCulture)
    {
        var item = new Criterion(propertyName, value, comparisonType, stringComparison);
        WithCriterion(item);
        return this;
    }

    public FilterBuilder<T> WithCriterion(Criterion criterion)
    {
        filter.Add(criterion);
        return this;
    }

    public FilterBuilder<T> WithOrderBy(string propertyName, ListSortDirection direction = ListSortDirection.Ascending)
    {
        var item = new OrderByProperty(propertyName, direction);
        WithOrderBy(item);
        return this;
    }

    public FilterBuilder<T> WithOrderBy(OrderByProperty orderBy)
    {
        filter.Add(orderBy);
        return this;
    }

    public FilterBuilder<T> WithPaging(int skip = 0, int? take = null)
    {
        var item = new Paging(skip, take);
        WithPaging(item);
        return this;
    }

    public FilterBuilder<T> WithPaging(Paging paging)
    {
        filter.Paging = paging;
        return this;
    }

    public Filter<T> Build() => filter;

}
