﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wsdot.Idl.Ifx.Filtering;

public static class FilteringConstants
{


    public const string EXPRESSION_PARAMETER = "e";

    public const string METHOD_NAME_CONTAINS = "CONTAINS";
    public const string METHOD_NAME_EQUALS = "EQUALS";
    public const string METHOD_NAME_LIKE = "LIKE";
    public const string METHOD_NAME_TO_LOWER = "ToLower";
    public const string METHOD_NAME_TO_STRING = "ToString";

    public const string ORDER_BY_DESCENDING = "OrderByDescending";
    public const string ORDER_BY = "OrderBy";
    public const string THEN_BY_DESCENDING = "ThenByDescending";
    public const string THEN_BY = "ThenBy";

    public const string PROPERTY_NAME_FUNCTIONS = "Functions";

    public static class Comparisons
    {

        public const string EQUALS = "equals";
        public const string NOT_EQUALS = "notequals";
        public const string GREATER_THAN = "greaterthan";
        public const string LESS_THAN = "lessthan";
        public const string CONTAINS = "contains";
        public const string LIKE = "like";

        // Optional short aliases
        public const string EQ = "eq";
        public const string NEQ = "neq";
        public const string GT = "gt";
        public const string LT = "lt";
    }

}
