﻿using System.Globalization;

namespace Wsdot.Idl.Ifx.Filtering;

public readonly record struct ComparisonContext(StringComparison StringComparison, CultureInfo? Culture = null)
{

    public CompareOptions CompareOptions => StringComparison switch
    {
        StringComparison.CurrentCultureIgnoreCase or StringComparison.InvariantCultureIgnoreCase or StringComparison.OrdinalIgnoreCase => CompareOptions.IgnoreCase,
        _ => CompareOptions.None
    };

    public CultureInfo EffectiveCulture => StringComparison switch
    {
        StringComparison.InvariantCulture or StringComparison.InvariantCultureIgnoreCase => CultureInfo.InvariantCulture,
        _ => Culture ?? CultureInfo.CurrentCulture
    };

}