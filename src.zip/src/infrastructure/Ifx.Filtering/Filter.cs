﻿using System.ComponentModel;
using Wsdot.Idl.Ifx.Filtering.Extensions;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Filtering;

public class Filter
{
    public static Filter Empty => new();

    public CriterionCollection Criteria { get; set; } = [];
    public OrderByPropertyCollection OrderBy { get; set; } = [];
    public Paging Paging { get; set; } = new();

    public Filter()
    {

    }

    public Filter(CriterionCollection criteria, OrderByPropertyCollection orderBy, Paging paging)
    {
        Criteria = criteria;
        OrderBy = orderBy;
        Paging = paging;
    }

}




