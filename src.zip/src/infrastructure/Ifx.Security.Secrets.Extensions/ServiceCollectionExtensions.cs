﻿using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.DependencyInjection;

namespace Wsdot.Idl.Ifx.Security.Secrets;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddKeyVaultSecrets(this IServiceCollection services, Uri vaultUri, TokenCredential? credential = null, Action<SecretClientOptions>? configureClient = null, Action<SecretCacheOptions>? configureCache = null)
    {
        var opts = new SecretClientOptions
        {
            Retry =
            {
                Mode = RetryMode.Exponential,
                MaxRetries = 5,
                Delay = TimeSpan.FromMilliseconds(200),
                MaxDelay = TimeSpan.FromSeconds(5)
            }
        };
        configureClient?.Invoke(opts);

        services.AddSingleton(new SecretClient(vaultUri, credential ?? new DefaultAzureCredential(), opts));
        services.AddMemoryCache();
        if (configureCache is not null) 
            services.Configure(configureCache);

        services.AddSingleton<ISecretProvider, KeyVaultSecretProvider>();
        return services;
    }
}