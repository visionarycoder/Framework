﻿namespace Wsdot.Idl.Utility.AuditLogging;

public record AuditEvent(string EventType, string Description);