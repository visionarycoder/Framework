﻿namespace Wsdot.Idl.Ifx.Proxy.Attributes;


[AttributeUsage(AttributeTargets.Method, Inherited = true)]
public sealed class IdempotentAttribute : Attribute;