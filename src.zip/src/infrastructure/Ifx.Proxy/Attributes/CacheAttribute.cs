﻿namespace Wsdot.Idl.Ifx.Proxy.Attributes;

[AttributeUsage(AttributeTargets.Method, Inherited = true)]
public sealed class CacheAttribute(int seconds) : Attribute
{
    public int Seconds { get; } = seconds;
}