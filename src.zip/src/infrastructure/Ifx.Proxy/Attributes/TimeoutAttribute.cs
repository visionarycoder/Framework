﻿namespace Wsdot.Idl.Ifx.Proxy.Attributes;

[AttributeUsage(AttributeTargets.Method, Inherited = true)]
public sealed class TimeoutAttribute(int milliseconds) : Attribute
{
    public int Milliseconds { get; } = milliseconds;
}