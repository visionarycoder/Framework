﻿namespace Wsdot.Idl.Ifx.Proxy.Attributes;

[AttributeUsage(AttributeTargets.Interface, Inherited = false)]
public sealed class ProxyContractAttribute : Attribute;