﻿namespace Wsdot.Idl.Ifx.Proxy.Attributes;

[AttributeUsage(AttributeTargets.Method, Inherited = true)]
public sealed class BulkheadAttribute(int maxConcurrency) : Attribute
{
    public int MaxConcurrency { get; } = maxConcurrency;
}