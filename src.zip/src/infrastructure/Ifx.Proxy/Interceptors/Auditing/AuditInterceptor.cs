﻿using Wsdot.Idl.Ifx.Messaging.Cqrs;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Auditing;

public sealed class AuditInterceptor(IAuditSink sink) 
    : IOrderedInterceptor
{

    public int Order => 200;

    public async Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {

        var sw = System.Diagnostics.Stopwatch.StartNew();
        var req = ctx.Args.FirstOrDefault() as IServiceMessageRequest;
        var corr = req?.CorrelationId ?? Guid.NewGuid();
        var metadata = req?.Metadata.ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
        var tenant = metadata?.GetValueOrDefault(ServiceMessageMetadata.TenantId);
        var pid = metadata?.GetValueOrDefault(ServiceMessageMetadata.PrincipalId);
        var name = metadata?.GetValueOrDefault(ServiceMessageMetadata.Name);
        var email = metadata?.GetValueOrDefault(ServiceMessageMetadata.Email);
        var mode = ctx.Items.TryGetValue("proxy.mode", out var proxyMode) ? proxyMode?.ToString() ?? "Service" : "Service";

        try
        {
            var result = await next(ctx).ConfigureAwait(false);
            await sink.WriteAsync(new AuditRecord(DateTimeOffset.UtcNow, ctx.Contract.FullName!, ctx.Method.Name, mode, corr.ToString(), tenant, pid, name, email, "Success", null, sw.ElapsedMilliseconds), ctx.CancellationToken);
            return result;
        }
        catch (Exception ex)
        {
            await sink.WriteAsync(new AuditRecord(DateTimeOffset.UtcNow, ctx.Contract.FullName!, ctx.Method.Name, mode, corr.ToString(), tenant, pid, name, email, "Failure", ex.GetType().Name, sw.ElapsedMilliseconds), ctx.CancellationToken);
            throw;
        }

    }

}