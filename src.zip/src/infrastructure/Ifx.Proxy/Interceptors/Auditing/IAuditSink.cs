﻿namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Auditing;

public interface IAuditSink
{
    Task WriteAsync(AuditRecord record, CancellationToken ct);
}