﻿using System.Collections.Concurrent;
using System.Reflection;
using Wsdot.Idl.Ifx.Proxy.Attributes;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Policies;

public sealed class AttributePolicyProvider
{

    readonly ConcurrentDictionary<MethodInfo, PolicyHints> cache = new();

    public PolicyHints Get(MethodInfo method) => cache.GetOrAdd(method, m =>
    {
        var idempotent = m.IsDefined(typeof(IdempotentAttribute), true);
        var noRetry = m.IsDefined(typeof(NoRetryAttribute), true);
        var timeout = m.GetCustomAttribute<TimeoutAttribute>(true)?.Milliseconds;
        var cacheSec = m.GetCustomAttribute<CacheAttribute>(true)?.Seconds;
        var bulkhead = m.GetCustomAttribute<BulkheadAttribute>(true)?.MaxConcurrency;
        return new PolicyHints(idempotent, noRetry, timeout, cacheSec, bulkhead);
    });

    public sealed record PolicyHints(bool IsIdempotent, bool NoRetry, int? TimeoutMs, int? CacheSeconds, int? BulkheadMax);

}