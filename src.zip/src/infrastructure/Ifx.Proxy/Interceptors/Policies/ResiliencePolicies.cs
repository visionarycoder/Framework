﻿using Polly;
using Polly.Retry;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Policies;

public static class ResiliencePolicies
{
    public static AsyncRetryPolicy DefaultRetry => Policy.Handle<Exception>().WaitAndRetryAsync(3, i => TimeSpan.FromMilliseconds(50 * Math.Pow(2, i)));
}