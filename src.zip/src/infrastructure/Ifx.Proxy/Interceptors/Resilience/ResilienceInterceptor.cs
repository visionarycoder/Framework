﻿using Polly;
using Polly.Bulkhead;
using Polly.Timeout;
using Wsdot.Idl.Ifx.Proxy.Contracts;
using Wsdot.Idl.Ifx.Proxy.Interceptors.Policies;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Resilience;

public sealed class ResilienceInterceptor(AttributePolicyProvider policies) : IOrderedInterceptor
{
    public int Order => -120;

    public Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        ArgumentNullException.ThrowIfNull(ctx);
        ArgumentNullException.ThrowIfNull(next);

        var hints = policies.Get(ctx.Method);

        var timeout = hints.TimeoutMs is int ms and > 0
            ? Policy.TimeoutAsync<object?>(TimeSpan.FromMilliseconds(ms), TimeoutStrategy.Optimistic)
            : Policy.TimeoutAsync<object?>(TimeSpan.FromSeconds(5), TimeoutStrategy.Optimistic);

        var retryCount = hints.IsIdempotent
            ? 3
            : 2;

        Func<int, TimeSpan> SleepDurationProvider()
        {
            return attempt =>
                hints.IsIdempotent
                    ? TimeSpan.FromMilliseconds(60 * attempt + Random.Shared.Next(0, 60))
                    : TimeSpan.FromMilliseconds(120 * attempt + Random.Shared.Next(0, 120));
        }

        AsyncPolicy<object?> retry = hints.NoRetry
            ? Policy.NoOpAsync<object?>()
            : Policy<object?>.Handle<Exception>(ProxyErrorClassifier.IsTransient).WaitAndRetryAsync(retryCount: retryCount, sleepDurationProvider: SleepDurationProvider());

        AsyncBulkheadPolicy<object?>? bulkhead = null;
        if (hints.BulkheadMax is int max && max > 0)
        {
            bulkhead = Policy.BulkheadAsync<object?>(maxParallelization: max, maxQueuingActions: int.MaxValue);
        }

        var pipeline = bulkhead is null
            ? Policy.WrapAsync<object?>(timeout, retry)
            : Policy.WrapAsync<object?>(timeout, bulkhead, retry);

        return pipeline.ExecuteAsync(_ => next(ctx), ctx.CancellationToken);
    }
}