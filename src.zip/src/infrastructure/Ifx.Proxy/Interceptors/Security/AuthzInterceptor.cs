﻿using Microsoft.Extensions.Logging;
using Wsdot.Idl.Ifx.Exceptions;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Security;

public sealed class AuthzInterceptor(ILogger<AuthzInterceptor> logger, ICallerContext caller) 
    : IOrderedInterceptor
{
    public int Order => -50;

    public Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        var contract = ctx.Contract.FullName!;
        var method = ctx.Method.Name;

        // Enforce tenancy presence
        if (string.IsNullOrWhiteSpace(caller.TenantId))
        {
            throw new NonRetryableTransportException("Missing tenant context.");
        }

        // Enforce permission
        if (!caller.HasPermission(contract, method))
        {
            logger.LogWarning("Authorization failed for {Principal} on {Contract}.{Method} (tenant {Tenant})", caller.PrincipalId, contract, method, caller.TenantId);
            throw new NonRetryableTransportException("Not authorized.");
        }

        // Stamp into context for downstream implementations (optional)
        ctx.Items["tenantId"] = caller.TenantId!;
        ctx.Items["principalId"] = caller.PrincipalId ?? "anonymous";

        return next(ctx);
    }
}