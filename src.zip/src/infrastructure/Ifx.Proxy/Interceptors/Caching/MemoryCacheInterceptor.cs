﻿using Microsoft.Extensions.Caching.Memory;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Caching;

public sealed class MemoryCacheInterceptor(IMemoryCache cache) : IOrderedInterceptor
{
    public int Order => 50;

    public Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        // Only cache Task<T> methods; skip commands.
        if (ctx.Method.ReturnType.IsGenericType is false)
        {
            return next(ctx);
        }

        var key = $"{ctx.Contract.FullName}:{ctx.Method.Name}:{string.Join("|", ctx.Args.Select(a => a?.GetHashCode() ?? 0))}";
        if (cache.TryGetValue(key, out var hit))
        {
            return Task.FromResult(hit);
        }

        return DoAsync();
        async Task<object?> DoAsync()
        {
            var value = await next(ctx);
            cache.Set(key, value, TimeSpan.FromMinutes(1));
            return value;
        }
    }
}