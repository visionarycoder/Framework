﻿using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Interceptors.Logging;

public sealed class LoggingInterceptor(ILogger<LoggingInterceptor> log) : IOrderedInterceptor
{
    public int Order => -100; // run early
    public async Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            log.LogInformation("→ {Contract}.{Method}({Args})", ctx.Contract.Name, ctx.Method.Name, string.Join(", ", ctx.Args.Select(a => a?.ToString() ?? "null")));
            var result = await next(ctx);
            log.LogInformation("← {Contract}.{Method} in {Elapsed}ms", ctx.Contract.Name, ctx.Method.Name, stopwatch.ElapsedMilliseconds);
            return result;
        }
        catch (Exception ex)
        {
            log.LogError(ex, "✖ {Contract}.{Method} failed", ctx.Contract.Name, ctx.Method.Name);
            throw;
        }
    }
}