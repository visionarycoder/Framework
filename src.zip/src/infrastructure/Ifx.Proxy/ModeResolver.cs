﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy;

public sealed class ModeResolver(IServiceProvider services, IOptionsMonitor<ProxyOptions> options)
{
    public object Resolve(Type contract)
    {
        var cfg = options.CurrentValue;
        var key = cfg.ContractModes.TryGetValue(contract.FullName!, out var mode)
            ? mode.ToString()
            : cfg.DefaultMode.ToString();

        return services.GetRequiredKeyedService(contract, key);
    }
}