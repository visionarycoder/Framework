﻿using System.Reflection;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy;

internal sealed class ComponentProxy<TContract>(ModeResolver resolver, IEnumerable<IInterceptor> interceptors, IServiceProvider services) : DispatchProxy 
    where TContract : class
{

    public const string RESOLVER = "resolver";
    public const string INTERCEPTORS = "interceptors";
    public const string SERVICES = "services";

    readonly Dictionary<MethodInfo, InvocationDelegate> cache = new();

    protected override object? Invoke(MethodInfo targetMethod, object?[]? args) => throw new NotSupportedException("Use async signatures (Task / Task<T>).");

    protected Task InvokeAsync(MethodInfo m, object?[]? a) => InvokeCoreAsync<object?>(m, a);

    protected Task<T> InvokeAsyncT<T>(MethodInfo m, object?[]? a) => InvokeCoreAsync<T>(m, a);

    async Task<T> InvokeCoreAsync<T>(MethodInfo method, object?[]? args)
    {

        if (!cache.TryGetValue(method, out var del))
        {
            del = BuildPipeline(method);
            cache[method] = del;
        }

        var ctx = new InvocationContext
        {
            Contract = typeof(TContract),
            Method = method,
            Args = args ?? [],
            Services = services,
            CancellationToken = default
        };

        var result = await del(ctx).ConfigureAwait(false);
        return result is T t
            ? t 
            : default!;
    }

    InvocationDelegate BuildPipeline(MethodInfo method)
    {

        InvocationDelegate terminal = async ctx =>
        {
            var impl = resolver.Resolve(ctx.Contract);
            var result = method.Invoke(impl, ctx.Args);
            if (result is not Task task)
            {
                return result;
            }
            await task.ConfigureAwait(false);
            if (result.GetType().IsGenericType)
            {
                return result.GetType().GetProperty("Result")!.GetValue(result);
            }
            return null;
        };
        var ordered = interceptors.OrderBy(i => (i as IOrderedInterceptor)?.Order ?? 0).ToArray();
        return ordered.Reverse().Aggregate(terminal, (next, current) => c => current.InvokeAsync(c, next));
    }

}