﻿namespace Wsdot.Idl.Ifx.Proxy;

public sealed record ProxyErrorClassification(ProxyRetryKind Kind, TimeSpan? RetryAfter = null, string? Reason = null);