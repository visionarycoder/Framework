﻿using Microsoft.Extensions.DependencyInjection;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Factories;

public sealed class HybridProxyFactory(IServiceProvider services) : IProxyFactory
{
    public T Create<T>() where T : class
    {
        var contract = typeof(T);
        var genName = $"{contract.Namespace}.Generated.{contract.Name}Proxy";
        var gen = contract.Assembly.GetType(genName);
        if (gen is not null)
        {
            var instance = Activator.CreateInstance(gen,
                services.GetRequiredService<ModeResolver>(),
                services.GetRequiredService<IEnumerable<IInterceptor>>());
            return (T)instance!;
        }

        return services.GetRequiredService<ProxyFactory>().Create<T>();
    }
}