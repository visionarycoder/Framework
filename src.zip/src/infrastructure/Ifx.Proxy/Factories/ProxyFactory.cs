﻿using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using Wsdot.Idl.Ifx.Proxy.Contracts;
using static System.Reflection.BindingFlags;
#pragma warning disable S3011

namespace Wsdot.Idl.Ifx.Proxy.Factories;

public sealed class ProxyFactory(IServiceProvider services) : IProxyFactory
{
    public T Create<T>() where T : class
    {
        var resolver = services.GetRequiredService<ModeResolver>();
        var interceptors = services.GetRequiredService<IEnumerable<IInterceptor>>();
        var proxy = DispatchProxy.Create<T, ComponentProxy<T>>();
        var impl = (ComponentProxy<T>)(object)proxy!;
        typeof(ComponentProxy<T>).GetField(ComponentProxy<T>.RESOLVER, Default | Instance | NonPublic)!.SetValue(impl, resolver);
        typeof(ComponentProxy<T>).GetField(ComponentProxy<T>.INTERCEPTORS, Default | Instance | NonPublic)!.SetValue(impl, interceptors);
        typeof(ComponentProxy<T>).GetField(ComponentProxy<T>.SERVICES, Default | Instance | NonPublic)!.SetValue(impl, services);
        return proxy!;
    }
}
