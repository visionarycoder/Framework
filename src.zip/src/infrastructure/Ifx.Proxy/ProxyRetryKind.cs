﻿namespace Wsdot.Idl.Ifx.Proxy;

public enum ProxyRetryKind { None, Retriable, Throttle, Fatal }