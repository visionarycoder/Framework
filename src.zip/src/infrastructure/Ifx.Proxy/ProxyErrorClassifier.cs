﻿using Wsdot.Idl.Ifx.Exceptions;

namespace Wsdot.Idl.Ifx.Proxy;

public partial class ProxyErrorClassifier
{
    
    public bool IsTransient(Exception ex) => ex is TimeoutException || ex is RetryableTransportException || (ex.Data["IsTransient"] as bool?) == true;

}