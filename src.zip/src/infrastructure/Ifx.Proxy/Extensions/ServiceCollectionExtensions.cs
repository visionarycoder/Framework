﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Wsdot.Idl.Ifx.Proxy.Contracts;
using Wsdot.Idl.Ifx.Proxy.Factories;

namespace Wsdot.Idl.Ifx.Proxy.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddProxies(this IServiceCollection services, Action<ProxyOptions>? configure = null)
    {
        services.TryAddSingleton<ModeResolver>();
        services.TryAddSingleton<ProxyFactory>();
        services.TryAddSingleton<IProxyFactory, HybridProxyFactory>();
        if (configure is not null)
        {
            services.Configure(configure);
        }
        return services;
    }
}