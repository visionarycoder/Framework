﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public interface IProxyFactory
{
    T Create<T>() where T : class;
}