﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public sealed class ProxyOptions
{
    public ProxyMode DefaultMode { get; set; } = ProxyMode.Service;
    public Dictionary<string, ProxyMode> ContractModes { get; init; } = new(); // key = typeof(T).FullName
}