﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public enum ProxyMode { Service, Emulator, Simulator }