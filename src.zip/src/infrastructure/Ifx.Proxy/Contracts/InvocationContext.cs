﻿using System.Reflection;

namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public sealed class InvocationContext
{
    public required Type Contract { get; init; }
    public required MethodInfo Method { get; init; }
    public required object?[] Args { get; init; }
    public required IServiceProvider Services { get; init; }
    public CancellationToken CancellationToken { get; init; }
    public IDictionary<string, object> Items { get; } = new Dictionary<string, object>();
}