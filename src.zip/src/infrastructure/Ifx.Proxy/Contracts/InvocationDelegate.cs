﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public delegate Task<object?> InvocationDelegate(InvocationContext context);