﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public interface IInvocationClient
{
    Task<object?> InvokeAsync(InvocationEnvelope envelope);
}