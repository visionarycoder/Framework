﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public interface ICallerContext
{
    string? TenantId { get; }
    string? PrincipalId { get; }
    bool HasPermission(string contract, string method);
}