﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public interface IOrderedInterceptor : IInterceptor
{
    int Order { get; }
}