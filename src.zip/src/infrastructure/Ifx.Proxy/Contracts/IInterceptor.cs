﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public interface IInterceptor
{
    Task<object?> InvokeAsync(InvocationContext ctx, InvocationDelegate next);
}