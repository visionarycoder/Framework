﻿namespace Wsdot.Idl.Ifx.Proxy.Contracts;

public sealed class InvocationEnvelope
{
    public required string Contract { get; init; }
    public required string Operation { get; init; }
    public required object?[] Args { get; init; }
    public required Type[] ArgTypes { get; init; }
    public required Type ReturnType { get; init; }
    public string? CorrelationId { get; init; }
    public CancellationToken CancellationToken { get; init; } = CancellationToken.None;
}