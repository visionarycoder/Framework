﻿using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Clients;

public sealed class EmulatorClient(IServiceProvider serviceProvider) : IInvocationClient
{
    public Task<object?> InvokeAsync(InvocationEnvelope envelope) => new InProcClient(serviceProvider).InvokeAsync(envelope);
}