﻿using Microsoft.Extensions.DependencyInjection;
using Wsdot.Idl.Ifx.Proxy.Contracts;

namespace Wsdot.Idl.Ifx.Proxy.Clients;

public sealed class InProcClient(IServiceProvider serviceProvider) : IInvocationClient
{
    public async Task<object?> InvokeAsync(InvocationEnvelope envelope)
    {
        var service = serviceProvider.GetRequiredService(Type.GetType(envelope.Contract)!); // expects TContract to be registered with an implementation
        var method = service.GetType().GetMethod(envelope.Operation, envelope.ArgTypes) ?? throw new MissingMethodException(envelope.Contract, envelope.Operation);
        var result = method.Invoke(service, envelope.Args);
        return result is Task t 
            ? await UnwrapAsync(t, envelope.ReturnType) 
            : result;
    }

    static async Task<object?> UnwrapAsync(Task task, Type returnType)
    {
        await task.ConfigureAwait(false);
        if (returnType == typeof(void) || returnType == typeof(object))
        {
            return null;
        }
        return task.GetType().GetProperty("Result")?.GetValue(task);
    }
}