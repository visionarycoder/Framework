﻿using System.Net.Sockets;
using System.Reflection;
using Microsoft.Azure.Cosmos;
using Microsoft.Data.SqlClient;

namespace Wsdot.Idl.Ifx.Proxy;

// (Support either SqlClient)
#if HAS_SYSTEM_SQLCLIENT
using System.Data.SqlClient;
#endif
#if HAS_MICROSOFT_SQLCLIENT
using Azure;
#endif
#if HAS_AZURE_CORE
using Azure.Identity;
#endif
#if HAS_AZURE_SERVICEBUS
using Azure.Messaging.EventHubs;
#endif
#if HAS_AZURE_EVENTHUBS
using Azure.Messaging.ServiceBus;
#endif
#if HAS_AZURE_COSMOS
#endif
#if HAS_AZURE_IDENTITY
#endif

public partial class ProxyErrorClassifier
{
    public ProxyErrorClassification Classify(Exception error)
    {
        var ex = Unwrap(error);

        var azure = ClassifyAzure(ex);
        if (azure is not null)
        {
            return azure;
        }

        var sql = ClassifySql(ex);
        if (sql is not null)
        {
            return sql;
        }

        var generic = ClassifyGeneric(ex);
        if (generic is not null)
        {
            return generic;
        }

        return new(ProxyRetryKind.None, null, ex.GetType().Name);
    }

    // -------------------------
    // Azure SDK classification
    // -------------------------
    private static ProxyErrorClassification? ClassifyAzure(Exception ex)
    {
#if HAS_AZURE_CORE
        if (ex is RequestFailedException rfe)
        {
            if (IsRetriableStatus(rfe.Status))
            {
                return new(ProxyRetryKind.Retriable, TryGetRetryAfter(rfe), $"Azure.RequestFailed:{rfe.Status}");
            }

            if ((rfe.Status == 409 || rfe.Status == 412) && TryGetRetryAfter(rfe) is { } ra)
            {
                return new(ProxyRetryKind.Retriable, ra, $"Azure.RequestFailed:{rfe.Status}");
            }

            if (rfe.Status == 429)
            {
                return new(ProxyRetryKind.Throttle, TryGetRetryAfter(rfe), "Azure.Throttled");
            }
        }
#endif

#if HAS_AZURE_SERVICEBUS
        if (ex is ServiceBusException sbe)
        {
            if (sbe.Reason == ServiceBusFailureReason.ServiceBusy)
            {
                return new(ProxyRetryKind.Throttle, TryGetRetryAfter(ex), "ServiceBus.ServiceBusy");
            }

            return sbe.IsTransient
                ? new(ProxyRetryKind.Retriable, TryGetRetryAfter(ex), $"ServiceBus.{sbe.Reason}")
                : new(ProxyRetryKind.None, null, $"ServiceBus.{sbe.Reason}");
        }
#endif

#if HAS_AZURE_EVENTHUBS
        if (ex is EventHubsException ehe)
        {
            if (ehe.Reason == EventHubsException.FailureReason.ServiceBusy)
            {
                return new(ProxyRetryKind.Throttle, TryGetRetryAfter(ex), "EventHubs.ServiceBusy");
            }

            return ehe.IsTransient
                ? new(ProxyRetryKind.Retriable, TryGetRetryAfter(ex), $"EventHubs.{ehe.Reason}")
                : new(ProxyRetryKind.None, null, $"EventHubs.{ehe.Reason}");
        }
#endif

#if HAS_AZURE_COSMOS
        if (ex is CosmosException ce)
        {
            var status = (int)ce.StatusCode;

            if (status == 429)
            {
                return new(ProxyRetryKind.Throttle, ce.RetryAfter, "Cosmos.Throttled");
            }

            if (IsRetriableStatus(status) || status == 449 /* legacy Retry With */)
            {
                return new(ProxyRetryKind.Retriable, ce.RetryAfter, $"Cosmos:{status}");
            }
        }
#endif

#if HAS_AZURE_IDENTITY
        if (ex is AuthenticationFailedException afe)
        {
            var inner = Unwrap(afe.InnerException ?? afe);
            if (inner is HttpRequestException or SocketException or TimeoutException)
            {
                return new(ProxyRetryKind.Retriable, TryGetRetryAfter(inner), "Identity.Transport");
            }

            return new(ProxyRetryKind.None, null, "Identity.AuthenticationFailed");
        }
#endif
        return null;
    }

    // -------------------------
    // Azure SQL classification
    // -------------------------
    private static ProxyErrorClassification? ClassifySql(Exception ex)
    {
#if HAS_SYSTEM_SQLCLIENT || HAS_MICROSOFT_SQLCLIENT
        var (isSql, sqlEx) = TryGetSqlException(ex);
        if (isSql && sqlEx is not null)
        {
            var transientNumbers = new[] { 4060, 10928, 10929, 40197, 40501, 40613, 49918, 49919, 49920, 4221, 11001 };

            var isTransient = sqlEx.Errors
                .Cast<object>()
                .Select(new Func<object, dynamic>(e => e))
                .Any(new Func<dynamic, bool>
                (err =>
                {
                    try
                    {
                        var number = (int)err.Number;
                        var @class = (int)err.Class;
                        return transientNumbers.Contains(number) || @class >= 20;
                    }
                    catch { return false; }
                }));

            if (isTransient)
            {
                var ra = ExtractSqlRetryAfter(sqlEx) ?? TimeSpan.FromSeconds(5);
                return new(ProxyRetryKind.Retriable, ra, "SqlException.Transient");
            }

            // FIX: correct lambda parenthesis
            try
            {
                if (sqlEx.Errors.Cast<object>().Any(new Func<object, bool>(e => (int)((dynamic)e).Number == 40501)))
                {
                    return new(ProxyRetryKind.Throttle, ExtractSqlRetryAfter(sqlEx) ?? TimeSpan.FromSeconds(10), "SqlException.Throttled");
                }
            }
            catch { /* ignore */ }

            return new(ProxyRetryKind.None, null, "SqlException");
        }
#endif
        return null;
    }

    // -------------------------
    // Generic fallbacks
    // -------------------------
    private static ProxyErrorClassification? ClassifyGeneric(Exception ex)
    {
        if (ex is OperationCanceledException oce)
        {
            return oce.CancellationToken.IsCancellationRequested
                ? new(ProxyRetryKind.None, null, "CanceledByCaller")
                : new(ProxyRetryKind.Retriable, TimeSpan.FromSeconds(2), "Timeout/Cancel");
        }

        if (ex is TimeoutException)
        {
            return new(ProxyRetryKind.Retriable, TimeSpan.FromSeconds(2), "Timeout");
        }

        if (ex is HttpRequestException or SocketException)
        {
            return new(ProxyRetryKind.Retriable, TimeSpan.FromSeconds(2), ex.GetType().Name);
        }

        return null;
    }

    // -------------------------
    // Helpers
    // -------------------------
    private static Exception Unwrap(Exception ex)
    {
        while (true)
        {
            if (ex is AggregateException { InnerExceptions.Count: 1 } ae)
            {
                ex = ae.InnerExceptions[0]; 
                continue;
            }

            if (ex.InnerException is not null && (ex is TargetInvocationException or HttpRequestException))
            {
                ex = ex.InnerException; 
                continue;
            }
            return ex;
        }
    }

    private static bool IsRetriableStatus(int status) => status == 408 || status == 429 || (status >= 500 && status != 501 && status != 505);

#if HAS_AZURE_CORE
    // No headers on RequestFailedException; parse from message if present (best effort).
    private static TimeSpan? TryGetRetryAfter(RequestFailedException rfe) => ParseRetryAfterFromText(rfe.Message);
#endif

    private static TimeSpan? TryGetRetryAfter(Exception ex)
    {
#if HAS_AZURE_COSMOS
        if (ex is CosmosException { RetryAfter: not null } ce)
        {
            return ce.RetryAfter;
        }
#endif
        return ParseRetryAfterFromText(ex.Message);
    }

    private static TimeSpan? ParseRetryAfterFromText(string? text)
    {

        const string RETRY_AFTER = "retry-after:";
        const string RETRY_AFTER_MS = "x-ms-retry-after-ms:";

        string tail;
        string? digits;

        if (string.IsNullOrEmpty(text))
        {
            return null;
        }


        var idx = text.IndexOf(RETRY_AFTER, StringComparison.OrdinalIgnoreCase);
        if (idx >= 0)
        {
            tail = text.Substring(idx + RETRY_AFTER.Length).TrimStart();
            digits = new string(tail.TakeWhile(char.IsDigit).ToArray());
            if (int.TryParse(digits, out var seconds))
            {
                return TimeSpan.FromSeconds(Math.Max(0, seconds));
            }
        }

        idx = text.IndexOf(RETRY_AFTER_MS, StringComparison.OrdinalIgnoreCase);
        if (idx < 0)
        {
            return null;
        }

        tail = text.Substring(idx + RETRY_AFTER_MS.Length).TrimStart();
        digits = new string(tail.TakeWhile(char.IsDigit).ToArray());
        if (int.TryParse(digits, out var ms))
        {
            return TimeSpan.FromMilliseconds(Math.Max(0, ms));
        }

        return null;
    }

#if HAS_SYSTEM_SQLCLIENT || HAS_MICROSOFT_SQLCLIENT
    private static (bool ok, dynamic? sqlEx) TryGetSqlException(Exception ex)
    {
#if HAS_MICROSOFT_SQLCLIENT
        if (ex is SqlException ms)
        {
            return (true, ms);
        }
#endif
#if HAS_SYSTEM_SQLCLIENT
        if (ex is System.Data.SqlClient.SqlException sys) return (true, sys);
#endif
        return (false, null);
    }

    private static TimeSpan? ExtractSqlRetryAfter(dynamic sqlEx)
    {
        try
        {
            var msg = (string?)sqlEx.Message;
            if (!string.IsNullOrEmpty(msg))
            {
                const string KEY = "Retry-After:";
                var idx = msg.IndexOf(KEY, StringComparison.OrdinalIgnoreCase);
                if (idx >= 0)
                {
                    var tail = msg.Substring(idx + KEY.Length).Trim();
                    var token = new string(tail.TakeWhile(char.IsDigit).ToArray());
                    if (int.TryParse(token, out var s))
                    {
                        return TimeSpan.FromSeconds(s);
                    }
                }
            }
        }
        catch { /* ignore */ }
        return null;
    }
#endif
}
