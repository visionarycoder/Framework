﻿namespace Wsdot.Idl.Ifx.Security;

public sealed record UserInfo(string? TenantId, string? PrincipalId, string? Name, string? Email, string[] Roles, string? Ip, string? UserAgent, string CorrelationId);