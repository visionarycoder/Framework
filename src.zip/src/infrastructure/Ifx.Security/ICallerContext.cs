﻿namespace Wsdot.Idl.Ifx.Security;

public interface ICallerContext
{
    UserInfo Current { get; }
    bool HasPermission(string contract, string method);
}