﻿using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;

namespace Wsdot.Idl.Ifx.Security.Web;

public sealed class HttpCallerContext(IHttpContextAccessor http) : ICallerContext
{
    public UserInfo Current
    {
        get
        {
            var ctx = http.HttpContext;
            var corr = Activity.Current?.TraceId.ToString() ?? ctx?.TraceIdentifier ?? Guid.NewGuid().ToString("N");

            // No HTTP context (e.g., background work) -> return minimal context with correlation id
            if (ctx is null)
            {
                return new UserInfo(
                    TenantId: null,
                    PrincipalId: null,
                    Name: null,
                    Email: null,
                    Roles: Array.Empty<string>(),
                    Ip: null,
                    UserAgent: null,
                    CorrelationId: corr
                );
            }

            var u = ctx.User ?? new ClaimsPrincipal(new ClaimsIdentity());

            // Support both WS-Fed (ClaimTypes.Role) and JWT ("roles"/"role") role claims
            var roles = u.FindAll(ClaimTypes.Role).Select(r => r.Value)
                .Concat(u.FindAll("roles").Select(r => r.Value))
                .Concat(u.FindAll("role").Select(r => r.Value))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            // Prefer X-Forwarded-For when present (first IP), else use remote address
            var ip = ctx.Connection.RemoteIpAddress?.ToString();
            var xff = ctx.Request.Headers["X-Forwarded-For"].ToString();
            if (!string.IsNullOrWhiteSpace(xff))
            {
                var first = xff.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).FirstOrDefault();
                if (!string.IsNullOrEmpty(first)) ip = first;
            }

            // Correct header name; use HeaderNames.UserAgent to avoid typos
            var userAgent = ctx.Request.Headers[HeaderNames.UserAgent].ToString();

            return new UserInfo(
                TenantId: u.FindFirst("tid")?.Value ?? u.FindFirst("tenant_id")?.Value,
                PrincipalId: u.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? u.FindFirst("oid")?.Value,
                Name: u.Identity?.Name ?? u.FindFirst(ClaimTypes.Name)?.Value ?? u.FindFirst("name")?.Value,
                Email: u.FindFirst(ClaimTypes.Email)?.Value ?? u.FindFirst("preferred_username")?.Value,
                Roles: roles,
                Ip: ip,
                UserAgent: userAgent,
                CorrelationId: corr
            );
        }
    }

    public bool HasPermission(string contract, string method)
    {
        var ctx = http.HttpContext!;
        var claimsPrincipal = ctx.User;
        if (!claimsPrincipal.Identity?.IsAuthenticated ?? true)
        {
            return false;
        }

        // Admins can do anything
        if (claimsPrincipal.IsInRole("Admin"))
        {
            return true;
        }

        // Check for specific permission claim
        var required = $"{contract}.{method}";
        foreach (var claim in claimsPrincipal.FindAll("permission"))
        {
            if (string.Equals(claim.Value, required, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }
}