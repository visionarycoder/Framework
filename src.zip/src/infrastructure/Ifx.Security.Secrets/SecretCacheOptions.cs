﻿namespace Wsdot.Idl.Ifx.Security.Secrets;

/// <summary>
/// Options that control in-memory caching of secrets for <see cref="ISecretProvider"/> implementations.
/// </summary>
/// <remarks>
/// These options are consumed by <see cref="KeyVaultSecretProvider"/> when storing secrets in <c>IMemoryCache</c>.
/// The cache uses absolute expiration (no sliding window). A small refresh skew is recommended to reduce
/// thundering herds when many callers request the same secret near its expiration.
/// 
/// Configure via DI using <c>AddKeyVaultSecrets(..., configureCache: options =&gt; { ... })</c>.
/// </remarks>
/// <example>
/// Example registration:
/// <code language="csharp">
/// services.AddKeyVaultSecrets(
///     vaultUri: new Uri("https://contoso.vault.azure.net/"),
///     configureCache: o =>
///     {
///         o.AbsoluteExpiration = TimeSpan.FromMinutes(5);
///         o.RefreshSkew = TimeSpan.FromSeconds(20);
///         o.PreferLatestVersion = true;
///     });
/// </code>
/// </example>
public sealed class SecretCacheOptions
{
    /// <summary>
    /// Maximum duration a cached secret remains valid before eviction.
    /// </summary>
    /// <remarks>
    /// Must be positive and typically greater than <see cref="RefreshSkew"/>. Smaller values increase calls to the backing
    /// store (e.g., Azure Key Vault) but reduce staleness; larger values reduce calls but increase potential staleness.
    /// Default is 10 minutes.
    /// </remarks>
    public TimeSpan AbsoluteExpiration { get; set; } = TimeSpan.FromMinutes(10);

    /// <summary>
    /// Time subtracted from <see cref="AbsoluteExpiration"/> that providers may use to proactively refresh or
    /// to stagger concurrent refreshes and reduce cache stampedes.
    /// </summary>
    /// <remarks>
    /// Default is 30 seconds. The current <see cref="KeyVaultSecretProvider"/> uses per-key locks to avoid stampedes;
    /// <see cref="RefreshSkew"/> is reserved for scenarios where early/background refresh is implemented.
    /// </remarks>
    public TimeSpan RefreshSkew { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>
    /// When true, providers should favor retrieving the latest current (enabled) version of a secret.
    /// </summary>
    /// <remarks>
    /// Default is <see langword="true" />. The current <see cref="KeyVaultSecretProvider"/> always retrieves the latest
    /// current version (by passing a <see langword="null" /> version to Key Vault), so this setting is primarily for
    /// forward compatibility with providers that support explicit version selection/pinning.
    /// </remarks>
    public bool PreferLatestVersion { get; set; } = true;
}