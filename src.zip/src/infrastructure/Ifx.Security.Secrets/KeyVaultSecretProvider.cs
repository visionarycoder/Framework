﻿using System.Collections.Concurrent;

using Azure;
using Azure.Security.KeyVault.Secrets;

using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Wsdot.Idl.Ifx.Security.Secrets;

public sealed class KeyVaultSecretProvider(ILogger<KeyVaultSecretProvider> logger, SecretClient client, IMemoryCache cache, IOptions<SecretCacheOptions> options) 
    : ISecretProvider
{

    readonly SecretClient client = client ?? throw new ArgumentNullException(nameof(client));
    readonly SecretCacheOptions opt = options.Value;

    // local locks to avoid thundering herd on single key
    readonly ConcurrentDictionary<string, SemaphoreSlim> locks = new();

    public async Task<KeyVaultSecret> GetAsync(string name, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        var cacheKey = $"kv.secret:{name}";

        KeyVaultSecret hit;
        if (cache.TryGetValue(cacheKey, out hit))
        {
            return hit;
        }

        var gate = locks.GetOrAdd(name, _ => new(1, 1));
        await gate.WaitAsync(ct);
        try
        {
            // double-check after acquiring the lock
            if (cache.TryGetValue(cacheKey, out hit))
            {
                return hit;
            }

            KeyVaultSecret secret;
            try
            {
                secret = (await client.GetSecretAsync(name: name, version: null, cancellationToken: ct)).Value;
            }
            catch (RequestFailedException ex) when (IsTransient(ex))
            {
                // transient classification; rethrow to caller or retry here if you prefer
                ex.Data["IsTransient"] = true;
                throw;
            }

            var absolute = DateTimeOffset.UtcNow + opt.AbsoluteExpiration;
            var refreshAt = absolute - opt.RefreshSkew;
            // store with absolute expiration; you can also schedule a background refresh at refreshAt if desired
            cache.Set(cacheKey, secret, absolute);
            return secret;
        }
        finally
        {
            gate.Release();
        }
    }
    
    public async Task<string> GetValueAsync(string name, CancellationToken ct = default) => (await GetAsync(name, ct)).Value;

    public Task InvalidateAsync(string name)
    {
        cache.Remove($"kv.secret:{name}");
        return Task.CompletedTask;
    }

    public void InvalidateAll()
    {
        // IMemoryCache has no global clear; optionally track keys yourself or recreate the cache via DI scope boundaries.
        // If you want global clear, wrap IMemoryCache with your own keyed set.
        logger.LogInformation("InvalidateAll requested for KeyVaultSecretProvider; consider app recycle for full clear.");
    }

    static bool IsTransient(RequestFailedException ex) => ex.Status is 408 or 429 or >= 500;

}