﻿using Azure.Security.KeyVault.Secrets;

namespace Wsdot.Idl.Ifx.Security.Secrets;

/// <summary>
/// Abstraction over a secret source (e.g. Azure Key Vault) with in‑memory caching.
/// Implementations should:
///  - Validate <paramref name="name"/> (non-null / non-whitespace)
///  - Apply per-key concurrency control to avoid thundering herd
///  - Surface transient failures (do NOT silently swallow)
///  - Never log secret values
/// </summary>
public interface ISecretProvider
{
    /// <summary>
    /// Gets the full <see cref="KeyVaultSecret"/> (including metadata) for the given name.
    /// Implementations may serve from cache. Throws if not found or underlying call fails.
    /// </summary>
    Task<KeyVaultSecret> GetAsync(string name, CancellationToken ct = default);

    /// <summary>
    /// Convenience wrapper returning only the secret value (string).
    /// </summary>
    Task<string> GetValueAsync(string name, CancellationToken ct = default);

    /// <summary>
    /// Invalidates the cached entry (if present) for a single secret name.
    /// </summary>
    Task InvalidateAsync(string name); // single-key cache drop

    /// <summary>
    /// Invalidates all cached secrets (best effort). If the underlying cache
    /// cannot be globally cleared, implementation should log intent.
    /// </summary>
    void InvalidateAll();
}