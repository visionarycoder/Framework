﻿namespace Wsdot.Idl.Ifx.Proxy;

[AttributeUsage(AttributeTargets.Interface, Inherited = false)]
public sealed class ProxyContractAttribute : Attribute;