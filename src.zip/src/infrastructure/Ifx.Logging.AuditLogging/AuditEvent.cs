﻿namespace Wsdot.Idl.Ifx.Data.SqlServer.AuditLogging;

public record AuditEvent(string EventType, string Description);