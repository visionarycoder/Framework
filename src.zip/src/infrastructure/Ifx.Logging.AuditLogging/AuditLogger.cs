﻿using Microsoft.Extensions.Logging;
using Wsdot.Idl.Access.Audit.Orm;

namespace Wsdot.Idl.Ifx.Data.SqlServer.AuditLogging;

public class AuditLogger(ILogger<AuditLogger> logger, AuditAccess auditAccess)
{

    public async Task<bool> LogAsync(AuditEvent auditEvent)
    {
        //if (auditEvent == null)
        //{
        //    return false;
        //}

        //if (await ctx.Database.CanConnectAsync())
        //{
        //    ctx.ApplicationLogs.Add(auditEvent);
        //    await ctx.SaveChangesAsync();
        //    return true;
        //}
        return false;
    }

}