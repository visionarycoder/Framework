﻿using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Diagnostics;

namespace Wsdot.Idl.Ifx.Analyzers;

[DiagnosticAnalyzer(LanguageNames.CSharp)]
public sealed class RefactorAnalyzer : DiagnosticAnalyzer
{
    private const string DIAGNOSTIC_ID = "WSDOT0001";
    private const string TITLE = "Refactoring Required";
    private const string MESSAGE_FORMAT = "{0} - Submitted by {1}: {2}";
    private const string DESCRIPTION = "This code has been marked as needing refactoring.";
    private const string CATEGORY = "Refactoring";

    private static readonly DiagnosticDescriptor rule = new(DIAGNOSTIC_ID, TITLE, MESSAGE_FORMAT, CATEGORY, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: DESCRIPTION);

    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => [rule];

    public override void Initialize(AnalysisContext context)
    {
        context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
        context.EnableConcurrentExecution();
        context.RegisterSymbolAction(AnalyzeSymbol, SymbolKind.Method, SymbolKind.Property, SymbolKind.Field, SymbolKind.Event, SymbolKind.NamedType);
    }

    private void AnalyzeSymbol(SymbolAnalysisContext context)
    {
        var symbol = context.Symbol;

        // Look for the RefactorNeededAttribute
        var attribute = symbol
            .GetAttributes()
            .FirstOrDefault(attr => attr.AttributeClass?.ToDisplayString() == "Wsdot.Idl.Ifx.Attributes.RefactorAttribute" || attr.AttributeClass?.ToDisplayString() == "Wsdot.Idl.Ifx.Attributes.RefactorAttribute");

        if (attribute == null) 
            return;

        // Extract attribute arguments
        var reason = attribute.ConstructorArguments.Length > 0
            ? attribute.ConstructorArguments[0].Value?.ToString() ?? "No reason provided"
            : "No reason provided";

        var submitter = attribute.ConstructorArguments.Length > 1
            ? attribute.ConstructorArguments[1].Value?.ToString() ?? "Unknown"
            : "Unknown";

        var actionType = "Refactoring needed";
        if (attribute.ConstructorArguments.Length > 2 && attribute.ConstructorArguments[2].Value is int typeValue)
        {
            // Get enum type from the parameter's type symbol
            if (attribute.ConstructorArguments[2].Type is not INamedTypeSymbol { TypeKind: TypeKind.Enum } enumType)
            {
                actionType = $"Unknown enum type ({typeValue})";
            }
            else
            {
                // Find the enum member with matching value
                var enumMember = enumType
                    .GetMembers()
                    .OfType<IFieldSymbol>()
                    .FirstOrDefault(m => m.HasConstantValue && (int)m.ConstantValue == typeValue);

                if (enumMember != null)
                {
                    actionType = enumMember.Name;
                }
            }
        }
        var diagnostic = Diagnostic.Create(rule, symbol.Locations[0], actionType, submitter, reason);
        context.ReportDiagnostic(diagnostic);
    }
}