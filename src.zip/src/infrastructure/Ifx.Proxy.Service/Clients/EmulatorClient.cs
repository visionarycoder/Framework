﻿namespace Wsdot.Idl.Ifx.Proxy;

public sealed class EmulatorClient(IServiceProvider serviceProvider) : IInvocationClient
{
    public Task<object?> InvokeAsync(InvocationEnvelope envelope) => new InProcClient(serviceProvider).InvokeAsync(envelope);
}