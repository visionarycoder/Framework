﻿namespace Wsdot.Idl.Ifx.Proxy;

public sealed class SimulatorClient(IServiceProvider serviceProvider) : IInvocationClient
{
    public Task<object?> InvokeAsync(InvocationEnvelope envelope) => new InProcClient(serviceProvider).InvokeAsync(envelope); // reuse in-proc dispatch; resolve a simulator implementation via DI
}