﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

/// <summary>
/// Common interface for all service messages, both requests and responses.  Contains common properties to track message correlation
/// and timing throughout the system.
/// </summary>
public interface IServiceMessage
{

    /// <summary>
    /// Unique Id of the message.  Every request and response has a different Id.  
    /// </summary>
    Guid MessageId { get; set; }

    /// <summary>
    /// Correlates all messages that help implement a Manager request back to the originating Manager request.
    /// See ServiceMessageFactory.CreateFrom() for details, and the remarks on that method for usage guidelines.
    /// </summary>
    Guid CorrelationId { get; set; }

    /// <summary>
    /// UTC timestamp of when the message was created.
    /// </summary>
    DateTime TimestampUtc { get; set; }

    /// <summary>
    /// Gets a collection of metadata key-value pairs associated with the object.
    /// </summary>
    /// <remarks>This property is immutable after initialization. Use it to store additional information 
    /// about the object in a structured format.</remarks>
    public ICollection<KeyValuePair<string,string>> Metadata { get; set; }

}