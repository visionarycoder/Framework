﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

/// <summary>
/// Common interfaces for all request service messages.
/// </summary>
public interface IServiceMessageRequest : IServiceMessage
{
}