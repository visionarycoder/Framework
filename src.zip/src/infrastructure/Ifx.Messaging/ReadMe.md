# Purpose

Utility for Service Messaging.

## Usage

```csharp

// Create a new instance of the service message.
// Typically used in a client to start the call chain.
var request = ServiceMessageFactory<TServiceMessage>.Create();

// Create a new instance of the service message with a payload.
// Typically used between managers, engines, and accessors.
var response = ServiceMessageFactory<TServiceMessage>.Create(request);

```