﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public static class ServiceMessageMetadata
{
    public const string TenantId = "user.tenant";
    public const string PrincipalId = "user.id";
    public const string Name = "user.name";
    public const string Email = "user.email";
    public const string Roles = "user.roles";
    public const string Ip = "user.ip";
    public const string UserAgent = "user.ua";
}