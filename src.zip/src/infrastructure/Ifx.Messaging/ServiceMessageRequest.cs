﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

/// <summary>
/// Abstract base class for all request service messages.
/// </summary>
public abstract class ServiceMessageRequest : ServiceMessage, IServiceMessageRequest
{

}