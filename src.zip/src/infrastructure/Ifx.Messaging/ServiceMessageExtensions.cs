﻿using Wsdot.Idl.Ifx.Security;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public static class ServiceMessageExtensions
{
    public static void StampUser(this ServiceMessageRequest req, UserInfo userInfo)
    {

        if (req.Metadata.Count == 0)
        {
            return;
        }

        var metadata = req.Metadata.ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
        if (!string.IsNullOrWhiteSpace(userInfo.TenantId))
        {
            metadata[ServiceMessageMetadata.TenantId] = userInfo.TenantId!;
        }

        if (!string.IsNullOrWhiteSpace(userInfo.PrincipalId))
        {
            metadata[ServiceMessageMetadata.PrincipalId] = userInfo.PrincipalId!;
        }

        if (!string.IsNullOrWhiteSpace(userInfo.Name))
        {
            metadata[ServiceMessageMetadata.Name] = userInfo.Name!;
        }

        if (!string.IsNullOrWhiteSpace(userInfo.Email))
        {
            metadata[ServiceMessageMetadata.Email] = userInfo.Email!;
        }

        if (userInfo.Roles.Length > 0)
        {
            metadata[ServiceMessageMetadata.Roles] = string.Join(',', userInfo.Roles);
        }

        if (!string.IsNullOrWhiteSpace(userInfo.Ip))
        {
            metadata[ServiceMessageMetadata.Ip] = userInfo.Ip!;
        }

        if (!string.IsNullOrWhiteSpace(userInfo.UserAgent))
        {
            metadata[ServiceMessageMetadata.UserAgent] = userInfo.UserAgent!;
        }
    }
}