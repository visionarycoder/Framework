﻿/*
 * Copyright (c) 2025 WSDOT.
 */

using System.Text.RegularExpressions;
using Wsdot.Idl.Ifx.Extensions;

namespace Wsdot.Idl.Ifx.Mainframe;

/// <summary>
/// Helper class for working with COBOL data, e.g., EBCDIC floating point and
/// negative number representation.
/// </summary>
public static class CopybookHelper
{
    /// <summary>
    /// The following is a RegEx translation in English of the match by group.
    ///
    /// Note: The RegEx is based on a best effort. The user can still enter an
    /// invalid picture clause, e.g., XAA , but the logic will have an order of
    /// precedence, pick the first match and determine the length based on that.
    /// Also note that the main purpose of this helper library is not to
    /// validate picture clauses but rather be able to process all valid clauses
    /// correctly.
    ///
    /// X = Alphanumeric
    /// A = Alphabetic
    /// 9 = Numeric
    /// S = Signed Numeric
    /// V = Implicit Decimal
    ///
    /// Group 1: Match X, A, or 9 followed by a number in parentheses, the value
    /// of the group is equal to the number inside the parenthesis i.e. the
    /// length.
    ///
    /// Group 2: Match a series of Xs. The length is determined by the length of
    /// consecutive characters.
    ///
    /// Group 3: Match a series of As. The length is determined by the length of
    /// consecutive characters.
    ///
    /// Group 4: Match a series of 9s. The length is determined by the length of
    /// consecutive characters.
    ///
    /// Group 5: This group matches the number of decimal places. Match a "V"
    /// followed by a series of 9s. The length is determined by the length of
    /// consecutive characters.
    /// </summary>
    private const string FIELD_LENGTH_PATTERN = @"[XA9]\((\d*)\)|(X+)|(A+)|(9+)|V(9+)";

    public static readonly Regex FieldLengthRegex = new(FIELD_LENGTH_PATTERN, RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Dictionary<int, char> positiveValueToCharMap = new()
    {
        { 0, '{' }, { 1, 'A' }, { 2, 'B' }, { 3, 'C' }, { 4, 'D' },
        { 5, 'E' }, { 6, 'F' }, { 7, 'G' }, { 8, 'H' }, { 9, 'I' }
    };

    private static readonly Dictionary<int, char> negativeValueToCharMap = new()
    {
        { 0, '}' }, { 1, 'J' }, { 2, 'K' }, { 3, 'L' }, { 4, 'M' },
        { 5, 'N' }, { 6, 'O' }, { 7, 'P' }, { 8, 'Q' }, { 9, 'R' }
    };

    /// <summary>
    /// Returns the length of a COBOL variable based on the given picture
    /// clause, -1 otherwise.
    /// </summary>
    /// <param name="pictureClause">Picture clause (aka COBOL data type)</param>
    /// <returns></returns>
    private static int GetLengthFromPictureClause(string pictureClause)
    {
        var matches = FieldLengthRegex.Matches(pictureClause);

        // handle length declared inside parenthesis
        if ( (pictureClause.StartsWith("X", StringComparison.CurrentCultureIgnoreCase) ||
              pictureClause.StartsWith("A", StringComparison.CurrentCultureIgnoreCase) ||
              pictureClause.StartsWith("S", StringComparison.CurrentCultureIgnoreCase) ||
              pictureClause.StartsWith("9"))
             && pictureClause.Contains("("))
        {
            return int.TryParse(matches[0].Groups[1].Value, out var result) ? result : -1;
        }

        // handle length declared by consecutives
        if (pictureClause.Contains('X', StringComparison.CurrentCultureIgnoreCase) ||
            pictureClause.Contains('A', StringComparison.CurrentCultureIgnoreCase) ||
            pictureClause.Contains('S', StringComparison.CurrentCultureIgnoreCase) ||
            pictureClause.Contains('9'))
        {
            return matches[0].Groups[0].Length;
        }

        return -1;
    }

    /// <summary>
    /// Returns the number of decimals of a COBOL variable based on the given
    /// picture clause, -1 otherwise.
    /// </summary>
    /// <param name="pictureClause">Picture clause (aka COBOL data type)</param>
    /// <returns></returns>
    private static int GetNumberOfDecimalsFromPictureClause(string pictureClause)
    {
        var matches = FieldLengthRegex.Matches(pictureClause);

        if (pictureClause.Contains("V", StringComparison.CurrentCultureIgnoreCase))
        {
            return matches[1].Groups[5].Length;
        }

        return -1;
    }

    /// <summary>
    /// Converts the given string representing an integer or decimal into a cobol
    /// packed signed representation (last character is swapped).
    /// </summary>
    /// <param name="value">String representing integer value</param>
    /// <returns>String representing a packed numeric format</returns>
    private static bool ConvertToPackedFormat(string value, int length, bool isSigned,
        bool isFloat, int numberOfDecimalPlaces, out string result)
    {
        result = null;
        var lastDigitInt = 0;
        var intValue = 0;
        float floatValue = 0;
        string valueFormattedString = null;

        // check invalid input
        if (value == null || length <=0)
        {
            return false;
        }

        if (isFloat)
        {
            if (float.TryParse(value, out var output))
            {
                floatValue = output;
            }
            else
            {
                return false;
            }

            valueFormattedString = floatValue.ToString("F" + numberOfDecimalPlaces);
        }
        else
        {
            if (int.TryParse(value, out var output))
            {
                intValue = output;
            }
            else
            {
                return false;
            }

            valueFormattedString = intValue.ToString("D" + length);
        }

        if (isSigned) // replace last digit with appropriate character
        {
            var inputLastDigit = value[value.Length - 1].ToString();
            if (int.TryParse(inputLastDigit, out var output))
            {
                lastDigitInt = output;
            }
            else
            {
                return false;
            }

            var negativeValue = false;

            if (isFloat)
            {
                if (floatValue < (0.0f - Constants.FLOATING_POINT_ERROR))
                {
                    negativeValue = true;
                }
            }
            else
            {
                if (intValue < 0)
                {
                    negativeValue = true;
                }
            }

            // replace the last character appropriately
            if (negativeValue)
            {
                if (negativeValueToCharMap.TryGetValue(lastDigitInt, out var lastCharacter))
                {

                    result = valueFormattedString.Substring(0, valueFormattedString.Length - 1) + lastCharacter;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (positiveValueToCharMap.TryGetValue(lastDigitInt, out var lastCharacter))
                {
                    result = valueFormattedString.Substring(0, valueFormattedString.Length - 1) + lastCharacter;
                }
                else
                {
                    return false;
                }
            }
        }
        else
        {
            result = valueFormattedString;
        }

        // remove sign and decimal point if present
        result = result.Replace(".", "").Replace("-", "");

        // pad with zeroes and truncate
        result = result.PadLeft(length, '0').Substring(0, length);

        return true;
    }

    /// <summary>
    /// Converts the given string representing the value of a normal variable to a
    /// string representation of a COBOL variable according to the "type"
    /// specified in the picture clause.
    /// </summary>
    /// <param name="pictureClause">COBOL picture clause, e.g., "S9(4)V99"</param>
    /// <param name="value">string representing "normal" value</param>
    /// <param name="result">Converted string</param>
    /// <see cref="https://www.tutorialspoint.com/cobol/cobol_data_types.htm"/>>
    /// <returns>True in conversion was successful, false otherwise</returns>
    public static bool ConvertFromNormalToCobol(string pictureClause, string value, out string result)
    {
        result = string.Empty;
        var isSigned = false;
        var isFloat = false;
        var numberOfDecimalPlaces = 0;

        // invalid picture clause
        if (string.IsNullOrEmpty(pictureClause))
        {
            return false;
        }

        // determine length from picture clause, e.g., specified in paren or sequence
        var fieldLength = GetLengthFromPictureClause(pictureClause);

        // alphabetic or numeric
        if (pictureClause.StartsWith("X", StringComparison.CurrentCultureIgnoreCase) ||
            pictureClause.StartsWith("A", StringComparison.CurrentCultureIgnoreCase))
        {
            // pass thru ensuring length is correct, pad right with spaces
            var paddedValue = value.PadRight(fieldLength, ' ').Substring(0, fieldLength);
            result = paddedValue;
        }

        if (pictureClause.StartsWith("S9")) // signed numeric
        {
            isSigned = true;
        }

        // Note: Signed flag was set above in case it was present, the rest of the
        // functionality below is common to both
        if (pictureClause.StartsWith("9") || pictureClause.StartsWith("S9"))
        {
            if (pictureClause.Contains('V'))
            {
                isFloat = true;
                numberOfDecimalPlaces = GetNumberOfDecimalsFromPictureClause(pictureClause);
            }

            if (ConvertToPackedFormat(value, fieldLength, isSigned, isFloat, numberOfDecimalPlaces, out var packedResult))
            {
                result = packedResult;
            }
            else
            {
                return false;
            }
        }

        return true;
    }

    public static bool ConvertFromCobolToNormal(string value, out string result)
    {
        var lastCharacter = value[^1];
        string lastCharacterValue;
        int index;
        
        if (positiveValueToCharMap.TryGetKeyByValue(lastCharacter, out index, null))
        {
            result = $"{value[..^1]}{index}";
        }
        
        else if (negativeValueToCharMap.TryGetKeyByValue(lastCharacter, out index, null))
        {
            result = $"-{value[..^1]}{index}";
        }
        else
        {
            result = string.Empty;
            return false;
        }
        
        return true;
    }
}