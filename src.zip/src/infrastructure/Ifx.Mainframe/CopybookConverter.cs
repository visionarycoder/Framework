﻿using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;
#pragma warning disable SYSLIB1045

namespace Wsdot.Idl.Ifx.Mainframe;

public static class CopybookConverter
{
    private const string FIELD_LENGTH_PATTERN = @"[XA9]\((\d*)\)|(X+)|(A+)|(9+)|V(9+)";
    private const string DECIMAL_PICTURE_PATTERN = @"^S9\(\d+\)V9\d*$";
    private const string NUMERIC_PICTURE_PATTERN = @"9\((\d+)\)(V9\((\d+)\))?";

    private static readonly Regex fieldLengthRegex = new(FIELD_LENGTH_PATTERN, RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex decimalPictureRegex = new(DECIMAL_PICTURE_PATTERN, RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex numericPictureRegex = new(NUMERIC_PICTURE_PATTERN, RegexOptions.Compiled | RegexOptions.IgnoreCase);

    private static readonly Dictionary<char, (int Value, int Sign)> charToValueMap = new()
    {
        { '{', (0, 1) }, { 'A', (1, 1) }, { 'B', (2, 1) }, { 'C', (3, 1) }, { 'D', (4, 1) },
        { 'E', (5, 1) }, { 'F', (6, 1) }, { 'G', (7, 1) }, { 'H', (8, 1) }, { 'I', (9, 1) },
        { '}', (0, -1) }, { 'J', (1, -1) }, { 'K', (2, -1) }, { 'L', (3, -1) }, { 'M', (4, -1) },
        { 'N', (5, -1) }, { 'O', (6, -1) }, { 'P', (7, -1) }, { 'Q', (8, -1) }, { 'R', (9, -1) }
    };

    public static T Deserialize<T>(string input) where T : new()
    {
        var obj = new T();
        DeserializeInto(obj, input);
        return obj;
    }

    public static string Serialize<T>(T instance) where T : class
    {
        ArgumentException.ThrowIfNullOrEmpty(nameof(instance));
        
        var length = GetMaxOffsetAndLength(instance.GetType());
        var buffer = Enumerable.Repeat(' ', length).ToArray();
        SerializeInto(instance, buffer);
        return new string(buffer);
    }

    private static object ParseFieldValue(string picture, string value)
    {
        // Nothing to parse.
        if (string.IsNullOrEmpty(picture))
        {
            return value;
        }

        // Handle signed numeric with implied decimal, e.g., S9(11)V99
        if (decimalPictureRegex.IsMatch(picture))
        {
            return ParseZonedSignedDecimal(picture, value);
        }

        if (picture.StartsWith("X", StringComparison.CurrentCultureIgnoreCase))
        {
            return value.Trim();
        }

        if (picture.StartsWith('9'))
        {
            return picture.Contains('V') ? ParseZonedSignedDecimal(picture, value) : ConvertToInt(value);
        }

        if (picture.StartsWith("S9", StringComparison.CurrentCultureIgnoreCase))
        {
            var sign = GetSign(value);
            value = SwapLastChar(value);
            return picture.Contains('V') ? ParseZonedSignedDecimal(picture, value) * sign : ConvertToInt(value) * sign;
        }

        throw new ArgumentException($"Unsupported picture type: {picture}");
    }

    private static void DeserializeInto(object instance, string input)
    {
        foreach (var propertyInfo in instance.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            var copybookFieldAttribute = propertyInfo.GetCustomAttribute<CopybookFieldAttribute>();
            if (copybookFieldAttribute != null && copybookFieldAttribute.Offset + copybookFieldAttribute.Length <= input.Length)
            {
                var rawValue = input.Substring(copybookFieldAttribute.Offset, copybookFieldAttribute.Length);
                var parsed = ParseFieldValue(copybookFieldAttribute.Picture, rawValue);

                if (string.IsNullOrWhiteSpace(rawValue))
                    continue;
                
                propertyInfo.SetValue(instance, parsed);
            }
            else if (propertyInfo.PropertyType.IsClass && propertyInfo.PropertyType != typeof(string))
            {
                var nested = Activator.CreateInstance(propertyInfo.PropertyType);
                if (nested == null) continue;
                
                DeserializeInto(nested, input);
                propertyInfo.SetValue(instance, nested);
            }
        }
    }

    private static void SerializeInto(object instance, char[] buffer)
    {
        foreach (var prop in instance.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            var attr = prop.GetCustomAttribute<CopybookFieldAttribute>();
            var value = prop.GetValue(instance);

            if (attr != null)
            {
                var output = FormatValue(value, attr.Picture, attr.Length);
                for (var index = 0; index < attr.Length && index < output.Length; index++)
                    buffer[attr.Offset + index] = output[index];
            }
            else if (value != null && prop.PropertyType.IsClass && prop.PropertyType != typeof(string))
            {
                SerializeInto(value, buffer);
            }
        }
    }

    private static string FormatValue(object? value, string picture, int length)
    {
        if (value == null)
        {
            return new string(' ', length);
        }

        if (picture.StartsWith('X'))
        {
            return (value.ToString() ?? "").PadRight(length).Substring(0, length);
        }

        if (!picture.StartsWith("S9", StringComparison.Ordinal) && !picture.StartsWith('9'))
            return new string(' ', length);
        
        var match = numericPictureRegex.Match(picture);
        
        if (!match.Success)
            return new string(' ', length);

        var digitsBefore = int.Parse(match.Groups[1].Value, new NumberFormatInfo());
        var digitsAfter = match.Groups[3].Success ? int.Parse(match.Groups[3].Value, new NumberFormatInfo()) : 0;
        var totalDigits = digitsBefore + digitsAfter;

        var numeric = value switch
        {
            decimal d => ((long)(d * (decimal)Math.Pow(10, digitsAfter))).ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            double d => ((long)(d * Math.Pow(10, digitsAfter))).ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            float f => ((long)(f * Math.Pow(10, digitsAfter))).ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            int i => i.ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            long l => l.ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            uint u => u.ToString(CultureInfo.InvariantCulture).PadLeft(totalDigits, '0'),
            _ => value.ToString()?.PadLeft(totalDigits, '0') ?? ""
        };

        return numeric[..Math.Min(length, numeric.Length)];
    }

    private static int GetMaxOffsetAndLength(Type type)
    {
        var max = 0;
        foreach (var prop in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            var attr = prop.GetCustomAttribute<CopybookFieldAttribute>();
            if (attr != null)
            {
                max = Math.Max(max, attr.Offset + attr.Length);
            }
            else if (prop.PropertyType.IsClass && prop.PropertyType != typeof(string))
            {
                max = Math.Max(max, GetMaxOffsetAndLength(prop.PropertyType));
            }
        }
        return max;
    }

    private static int ConvertToInt(string value)
    {
        return int.TryParse(value, out var results) ? results : 0;
    }

    private static int GetSign(string value)
    {
        return charToValueMap.TryGetValue(value[^1], out var result)
            ? result.Sign
            : 1;
    }

    private static decimal ParseZonedSignedDecimal(string picture, string raw)
    {
        if (string.IsNullOrWhiteSpace(picture) || string.IsNullOrWhiteSpace(raw))
            return 0;
        
        var decimalPlaces = GetNumberOfDecimalsFromPictureClause(picture);
        var sign = GetSign(raw);
        var number = SwapLastChar(raw);

        if (decimalPlaces > 0)
            number = number.Insert(number.Length - decimalPlaces, ".");

        if (string.IsNullOrWhiteSpace(number))
            return 0;

        if (!decimal.TryParse(number, out var decimalValue))
            throw new FormatException($"Invalid numeric value: {raw}");

        return sign * decimalValue;
    }

    private static int GetNumberOfDecimalsFromPictureClause(string pictureClause)
    {
        var matches = fieldLengthRegex.Matches(pictureClause);

        if (pictureClause.Contains('V', StringComparison.CurrentCultureIgnoreCase))
        {
            return matches[1].Groups[5].Length;
        }

        return -1;
    }

    private static string SwapLastChar(string value)
    {
        if (charToValueMap.TryGetValue(value[^1], out var result))
        {
            value = value[..^1] + result.Value;
        }
        return value;
    }
    
}