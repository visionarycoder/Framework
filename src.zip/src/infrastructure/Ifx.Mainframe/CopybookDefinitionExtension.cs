﻿namespace Wsdot.Idl.Ifx.Mainframe;

internal static class CopybookDefinitionExtension
{

    public static CopybookDefinition AddLayout(this CopybookDefinition source, string layout)
    {
        var target = new CopybookDefinition(source.TableName, layout);
        return target;
    }

    public static bool HasLayout(this CopybookDefinition copybookDefinition)
    {
        return !string.IsNullOrEmpty(copybookDefinition.Layout);
    }

}