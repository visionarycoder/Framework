﻿namespace Wsdot.Idl.Ifx.Mainframe;

public class CopybookDefinition(string tableName, string layout)
{
            
    public static CopybookDefinition Empty => new ();

    public string TableName { get; } = tableName;
    public string Layout { get; } = layout;

    private CopybookDefinition()
        : this(string.Empty)
    {

    }

    public CopybookDefinition(string tableName)
        : this(tableName, string.Empty)
    {

    }

}