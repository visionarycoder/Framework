﻿namespace Wsdot.Idl.Ifx.Mainframe;

public static class ResponseCodesExtensions
{
    public static bool IsSuccess(this string responseCode) => responseCode == ResponseCode.SUCCESS;
    public static bool IsNotFound(this string responseCode) => responseCode == ResponseCode.NOT_FOUND;
    public static bool IsInvalid(this string responseCode) => responseCode == ResponseCode.INVALID;
    public static bool IsFailure(this string responseCode) => responseCode == ResponseCode.FAILURE;

    public static string GetReturnMessage(string responseCode, string tableName)
    {
        var suffix = $"{tableName} @ {DateTime.Now}";
        return responseCode switch
        {
            ResponseCode.SUCCESS => $"SUCCESS {suffix}",
            ResponseCode.NOT_FOUND => $"NOT FND {suffix}",
            ResponseCode.INVALID => $"INVALID {suffix}",
            ResponseCode.FAILURE => $"FAILURE {suffix}",
            _ => string.Empty
        };
    }

}