﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Ifx.Mainframe.UnitTests")]