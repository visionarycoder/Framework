﻿namespace Wsdot.Idl.Ifx.Mainframe;

/// <summary>
/// Don't use.
/// Prototype for supporting WebMethods calls into IDL
/// </summary>
public class CopybookHeader
{
    // 05 KAM010-CALLING-PROGRAM  PIC X(8)   positions 1 - 8
    public string CallingProgram { get; set; } = string.Empty;

    // 05 KAM010-RETURN-CODE      PIC S9(4)  positions 9 - 12
    public string ReturnCode { get; set; } = string.Empty;

    // 05 KAM010-RETURN-MESSAGE   PIC X(50)  positions 13 - 62
    public string ReturnMessage { get; set; } = string.Empty;

    // 05 KAM010-TABLE-NAME       PIC X(20)  positions 63 - 82
    public string TableName { get; set; } = string.Empty;

    // 05 KAM010-FUNCTION         PIC X(8)   positions 83 - 90
    public string Function { get; set; } = string.Empty;
}