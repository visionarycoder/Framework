﻿// ReSharper disable ClassNeverInstantiated.Global
namespace Wsdot.Idl.Ifx.Mainframe;

/// <summary>
/// Marks a generated property with the original COBOL copybook metadata.
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class CopybookFieldAttribute : Attribute
{
    /// <summary>
    /// The COBOL level number (e.g. 01, 05, 10) of the field in the copybook hierarchy.
    /// </summary>
    public int Level { get; init; }

    /// <summary>
    /// The exact COBOL field name, as written in the copybook.
    /// </summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>
    /// The cleaned PIC clause (e.g. "9(4)V99", "X(10)"), used to infer length and data type.
    /// </summary>
    public string Picture { get; init; } = string.Empty;

    /// <summary>
    /// The COBOL USAGE clause (e.g. "COMP-3", "COMP", "BINARY", "PACKED-DECIMAL"),
    /// indicating how the field is physically stored on the mainframe.
    /// <para>
    /// The serializer uses this to decide whether to treat the raw bytes as
    /// packed decimal, binary integer, zoned/display numeric, or alphanumeric.
    /// </para>
    /// </summary>
    public string? Usage { get; init; }

    /// <summary>
    /// If non-null, the name of the other field this one REDEFINES (overlays) in COBOL.
    /// </summary>
    public string? Redefines { get; init; }

    /// <summary>
    /// Whether the generated property should be init-only (true for KEY-FIELDS)
    /// or read/write (false for RESULTS-FIELDS).
    /// </summary>
    public bool ReadOnly { get; init; }

    /// <summary>
    /// The zero-based byte offset from the start of the record where this field begins.
    /// </summary>
    public int Offset { get; init; }

    /// <summary>
    /// The length in bytes (or characters) that this field occupies in the record.
    /// </summary>
    public int Length { get; init; }
}