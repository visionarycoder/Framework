﻿using System.Text;

namespace Wsdot.Idl.Ifx.Mainframe;

/// <summary>
/// Don't use.
/// Prototype for supporting WebMethods calls into IDL
/// </summary>
public static class CopybookHeaderParser
{

    public static CopybookHeader ParseHeader(string headerRecord)
    {

        // Safety check: Ensure we have at least 00 characters
        if (headerRecord == null || headerRecord.Length < 90)
        {
            throw new ArgumentException("Header record must be at least 90 characters long.");
        }

        // Create the result object
        var header = new CopybookHeader
        {
            // Positions here use zero-based indexing for Substring()
            // 1) Calling Program: positions 1–8 (COBOL), so Substring(0, 8)
            CallingProgram = headerRecord[..8].TrimEnd(),
            // 2) Return Code: positions 9–12 (COBOL), so Substring(8, 4) in C#
            ReturnCode = headerRecord.Substring(8, 4).Trim(),
            // 3) Return Message: positions 13–62 (COBOL), length = 50
            ReturnMessage = headerRecord.Substring(12, 50).TrimEnd(),
            // 4) Table Name: positions 63–82 (COBOL), length = 20
            TableName = headerRecord.Substring(62, 20).TrimEnd(),
            // 5) Function: positions 83–90 (COBOL), length = 8
            Function = headerRecord.Substring(82, 8).TrimEnd()
        };

        return header;
    }

    public static string RebuildHeader(CopybookHeader header)
    {

        // Ensure each field is padded or truncated to the right length:
        //   CallingProgram -> 8 chars
        //   ReturnCode -> 4 chars (S9(4))
        //   ReturnMessage -> 50 chars
        //   TableName -> 20 chars
        //   Function -> 8 chars

        // For ReturnCode, we keep it simple and force a 4-digit format
        // (Add sign-handling logic separately if negative codes are possible in your system.)

        // Build up the final string
        var sb = new StringBuilder(90);
        sb.Append((header.CallingProgram ?? "").PadRight(8)[..8]);
        sb.Append((header.ReturnCode ?? "").PadRight(4,'0')[..4]);
        sb.Append((header.ReturnMessage ?? "").PadRight(50)[..50]);
        sb.Append((header.TableName ?? "").PadRight(20)[..20]);
        sb.Append((header.Function ?? "").PadRight(8)[..8]);
        return sb.ToString();

    }

}