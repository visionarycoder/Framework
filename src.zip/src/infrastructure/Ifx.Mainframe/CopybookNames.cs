﻿using Wsdot.Idl.Ifx.Extensions;
// ReSharper disable IdentifierTypo

namespace Wsdot.Idl.Ifx.Mainframe;

public static class CopybookNames
{
    public const string AGPR = "AGPR";
    public const string APRD = "APRD";
    public const string APRF = "APRF";
    public const string BACC = "BACC";
    public const string CDOC = "CDOC";
    public const string CLDT = "CLDT";
    public const string CSPA = "CSPA";
    public const string CSPH = "CSPH";
    public const string CTXT = "CTXT";
    public const string CUCB = "CUCB";
    public const string CUSA = "CUSA";
    public const string CUST = "CUST";
    public const string EQNO = "EQNO";
    public const string FAGY = "FAGY";
    public const string FUND = "FUND";
    public const string GCAT = "GCAT";
    public const string GRUH = "GRUH";
    public const string GRUP = "GRUP";
    public const string KAGT = "KAGT";
    public const string LDAT = "LDAT";
    public const string OBJT = "OBJT";
    public const string OREC = "OREC";
    public const string ORED = "ORED";
    public const string OREH = "OREH";
    public const string OREL = "OREL";
    public const string ORGH = "ORGH";
    public const string ORGN = "ORGN";
    public const string ORGT = "ORGT";
    public const string ORPH = "ORPH";
    public const string ORPT = "ORPT";
    public const string PACC = "PACC";
    public const string PAGT = "PAGT";
    public const string PDAT = "PDAT";
    public const string PDOC = "PDOC";
    public const string PGRP = "PGRP";
    public const string PHDR = "PHDR";
    public const string POBJ = "POBJ";
    public const string PREC = "PREC";
    public const string PRED = "PRED";
    public const string PRPH = "PRPH";
    public const string PRPT = "PRPT";
    public const string SORG = "SORG";
    public const string WORD = "WORD";
    public const string WONT = "WONT";
    public const string XWON = "XWON";
    public const string PPAT = "PPAT";
    public const string PRPL = "PRPL";
    public const string RNTP = "RNTP";
    public const string SREV = "SREV";
    public const string STMT = "STMT";
    public const string VEND = "VEND";
    public const string WACT = "WACT";
    public const string WATH = "WATH";
    public const string WOCL = "WOCL";
    public const string XORG = "XORG";

    public static readonly IReadOnlyList<string> All = typeof(CopybookNames).AllConstantNames();

}