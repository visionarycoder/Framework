﻿using Wsdot.Idl.Ifx.Extensions;

namespace Wsdot.Idl.Ifx.Mainframe;

public static class ResponseCode
{

    public const string SUCCESS = "000{";
    public const string NOT_FOUND = "000D";
    public const string INVALID = "000H";
    public const string FAILURE = "001F";

    public static readonly IReadOnlyList<string> AllConstantNames = typeof(RunTypes).AllConstantNames();
    public static readonly IReadOnlyList<string> AllConstantValues = typeof(RunTypes).AllConstantValues();
}