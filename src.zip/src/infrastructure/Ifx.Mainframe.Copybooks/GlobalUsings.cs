﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Ifx.Mainframe.Copybooks.UnitTests")]