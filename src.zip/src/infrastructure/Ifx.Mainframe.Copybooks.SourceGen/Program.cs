﻿//using System.Diagnostics;

//using Wsdot.Idl.Ifx.Mainframe.Copybook.Generators;

//Console.WriteLine("Starting...");
//string? inputDir = null, outputDir = null, desiredNamespace = null;
//for (var i = 0; i < args.Length; i++)
//{
//    switch (args[i])
//    {
//        case "--input" when i + 1 < args.Length: inputDir = args[++i]; break;
//        case "--output" when i + 1 < args.Length: outputDir = args[++i]; break;
//        case "--namespace" when i + 1 < args.Length: desiredNamespace = args[++i]; break;
//    }
//}

//if (string.IsNullOrWhiteSpace(inputDir) || string.IsNullOrWhiteSpace(outputDir) || string.IsNullOrWhiteSpace(desiredNamespace))
//{
//    await Console.Error.WriteLineAsync("Usage: Copybook.GeneratorApp --input <copybookLayoutsDir> --output <generatedDir> --namespace <namespace>");
//    return ShowExit(2);
//}

//var copybookLayoutDir = new DirectoryInfo(Path.GetFullPath(inputDir));
//var generatedCopybookDir = new DirectoryInfo(Path.GetFullPath(outputDir));

//if (! copybookLayoutDir.Exists)
//{
//    await Console.Error.WriteLineAsync($"Input folder not found: {copybookLayoutDir.FullName}");
//    return ShowExit(3);
//}

//if (! generatedCopybookDir.Exists)
//{
//    Console.WriteLine($"Creating output folder: {generatedCopybookDir.FullName}");
//    generatedCopybookDir.Create();
//}

//var copybookGenerator = new CopybookGenerator(desiredNamespace);
//var (success, errors) = copybookGenerator
//    .GenerateCSharpFromCopybooks(generatedCopybookDir, copybookLayoutDir)
//    .GetAwaiter()
//    .GetResult();

//if (!success)
//{
//    await Console.Error.WriteLineAsync("Errors:");
//    foreach (var err in errors) 
//        await Console.Error.WriteLineAsync($"\t{err}");
//    return ShowExit(1);
//}

//Console.WriteLine("All copybooks processed successfully.");
//return ShowExit(0);

//int ShowExit(int returnCode)
//{
//    Console.WriteLine("__END__");
//    if (Debugger.IsAttached)
//        Console.ReadKey();
//    return returnCode;
//}