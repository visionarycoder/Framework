﻿using System.Buffers.Binary;
using System.Reflection;

namespace Wsdot.Idl.Ifx.Mainframe.Copybook.Generators;

public static class CopybookSerializer<T> where T : new()
{

    private record FieldMetadata(CopybookFieldAttribute Attribute, PropertyInfo Property, Func<string, object?> Parse, Func<object?, string> Format);

    //private static readonly FieldMetadata[] fieldMetadataCollection;

    static CopybookSerializer()
    {
        // cache reflection once
        //fieldMetadataCollection = typeof(T)
        //    .GetProperties(BindingFlags.Public | BindingFlags.Instance)
        //    .SelectMany(Flatten) // walk nested groups
        //    .Select
        //    (propertyInfo =>
        //        {
        //            var attr = propertyInfo.GetCustomAttribute<CopybookFieldAttribute>()!;
        //            var parsers = GetParsers(propertyInfo.PropertyType, attr);
        //            return new FieldMetadata(attr, propertyInfo, parsers.parse, parsers.format);
        //        }
        //    )
        //    .OrderBy(fieldMeta => fieldMeta.Attribute.Offset)
        //    .ToArray();
    }

    //#region  public API
    //public static TRecord From(char[] record)
    //{
    //    if (record.Length != 2000) throw new ArgumentException("Record must be 2000 chars");
    //    var obj = new TRecord();

    //    foreach (var f in fieldMetadataCollection)
    //    {
    //        string slice = new(record, f.Attribute.Offset, f.Attribute.Length);
    //        var value = f.Parse(slice);
    //        f.Property.SetValue(obj, value);
    //    }
    //    return obj;
    //}

    //public static char[] To(TRecord record)
    //{
    //    var buff = Enumerable.Repeat(' ', 2000).ToArray();  // COBOL space‑filled

    //    foreach (var f in fieldMetadataCollection)
    //    {
    //        var text = f.Format(f.Property.GetValue(record));
    //        if (text.Length != f.Attribute.Length)
    //            throw new InvalidOperationException($"{f.Property.Name} rendered length {text.Length} – expected {f.Attribute.Length}");

    //        text.CopyTo(0, buff, f.Attribute.Offset, f.Attribute.Length);
    //    }
    //    return buff;
    //}
    //#endregion

    #region  helpers
    private static IEnumerable<PropertyInfo> Flatten(PropertyInfo p)
    {
        // If no attribute ⇒ this is a group class – drill into its props.
        return p.GetCustomAttribute<CopybookFieldAttribute>() is not null
            ? [p]
            : p.PropertyType.GetProperties().SelectMany(Flatten);
    }

    private static (Func<string, object?> parse, Func<object?, string> format) GetParsers(Type clrType, CopybookFieldAttribute attribute)
    {
        var pic = attribute.Picture?.ToUpperInvariant() ?? "";
        var usage = attribute.Usage?.ToUpperInvariant() ?? "";      // COMP‑3, COMP, BINARY …

        var len = attribute.Length;                                // exact byte / char span
        var implied = pic.Contains('V') ? pic.Split('V')[1].Length : 0;

        // ------------------------------------------------------------------
        // 1) PACKED‑DECIMAL  (COMP‑3)
        // ------------------------------------------------------------------
        if (usage is "COMP-3" or "PACKED-DECIMAL")
        {
            return (
                parse => PackedToDecimal(parse.AsSpan(), implied),      // ⇐ helper from previous snippet
                format =>
                {
                    Span<char> buf = stackalloc char[len];
                    DecimalToPacked(buf, (decimal?)format ?? 0m, implied);   // ⇐ helper
                    return new string(buf);
                }
            );
        }

        // ------------------------------------------------------------------
        // 2) BINARY (COMP)  – big‑endian integers
        // ------------------------------------------------------------------
        if (usage is "COMP" or "BINARY")
        {
            return (
                parse =>
                {
                    Span<byte> bytes = stackalloc byte[len];
                    for (var i = 0; i < len; i++) bytes[i] = (byte)parse[i];
                    if (BitConverter.IsLittleEndian) bytes.Reverse();

                    return len switch
                    {
                        2 => (object?)BinaryPrimitives.ReadInt16BigEndian(bytes),
                        4 => BinaryPrimitives.ReadInt32BigEndian(bytes),
                        8 => BinaryPrimitives.ReadInt64BigEndian(bytes),
                        _ => null
                    };
                },
                format =>
                {
                    Span<byte> bytes = stackalloc byte[len];
                    var value = Convert.ToInt64(format ?? 0);

                    switch (len)
                    {
                        case 2: BinaryPrimitives.WriteInt16BigEndian(bytes, (short)value); break;
                        case 4: BinaryPrimitives.WriteInt32BigEndian(bytes, (int)value); break;
                        case 8: BinaryPrimitives.WriteInt64BigEndian(bytes, value); break;
                    }
                    if (BitConverter.IsLittleEndian) bytes.Reverse();

                    var buf = new char[len];
                    for (var i = 0; i < len; i++) buf[i] = (char)bytes[i];
                    return new string(buf);
                }
            );
        }

        // ------------------------------------------------------------------
        // 3) ZONED / DISPLAY numerics
        // ------------------------------------------------------------------
        if (clrType == typeof(uint) || clrType == typeof(uint?))
        {
            return (
                    parse => uint.TryParse(parse.Trim(), out var n) ? n : null,
                    format => ((uint?)format).GetValueOrDefault().ToString().PadLeft(len, '0')
                );
        }

        if (clrType == typeof(decimal) || clrType == typeof(decimal?))
        {
            return (
                parse =>
                {
                    var raw = parse.Trim();
                    if (raw.Length == 0)
                    {
                        return null;
                    }
                    return decimal.Parse(raw) / (decimal)Math.Pow(10, implied);
                },
                format =>
                {
                    var d = ((decimal?)format).GetValueOrDefault();
                    var scaled = (long)Math.Round(d * (decimal)Math.Pow(10, implied));
                    return scaled.ToString().PadLeft(len, '0');
                }
            );
        }

        // ------------------------------------------------------------------
        // 4) Alphanumeric (PIC X…)
        // ------------------------------------------------------------------
        return (
            parse => parse.TrimEnd(),
            format => ((string?)format ?? string.Empty).PadRight(len)
            );
    }

    public static decimal PackedToDecimal(ReadOnlySpan<char> buf, int implied)
    {
        Span<byte> bytes = stackalloc byte[buf.Length / 2];
        for (var i = 0; i < bytes.Length; i++)
            bytes[i] = (byte)((FromHex(buf[i * 2]) << 4) | FromHex(buf[i * 2 + 1]));

        var signNibble = bytes[^1] & 0x0F;
        var negative = signNibble is 0x0D or 0x0B;
        bytes[^1] &= 0xF0;

        ulong value = 0;
        foreach (var b in bytes)
            value = value * 100 + (ulong)((b >> 4) * 10 + (b & 0x0F));

        var scaled = value / (decimal)Math.Pow(10, implied);
        return negative ? -scaled : scaled;
    }

    public static void DecimalToPacked(Span<char> buf, decimal val, int implied)
    {
        var neg = val < 0;
        var scaled = (ulong)(Math.Abs(val) * (decimal)Math.Pow(10, implied));

        for (var i = buf.Length - 1; i >= 0; i -= 2)
        {
            var d1 = (int)(scaled % 10); scaled /= 10;
            var d2 = (int)(scaled % 10); scaled /= 10;
            var b = (byte)((d2 << 4) | d1);
            buf[i] = ToHex(b & 0x0F);
            buf[i - 1] = ToHex(b >> 4);
        }
        // sign nibble
        buf[^1] = neg ? 'D' : 'C';
    }

    public static int FromHex(char c) => c <= '9' ? c - '0' : char.ToUpperInvariant(c) - 'A' + 10;

    public static char ToHex(int v) => (char)(v < 10 ? '0' + v : 'A' + (v - 10));
    #endregion

}