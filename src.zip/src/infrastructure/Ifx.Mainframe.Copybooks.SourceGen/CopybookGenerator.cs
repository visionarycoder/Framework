﻿using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

#pragma warning disable SYSLIB1045

namespace Wsdot.Idl.Ifx.Mainframe.Copybook.Generators;

public class CopybookGenerator(string desiredNamespace = "Wsdot.Idl.Ifx.Mainframe.Copybook.", ILogger? logger = null)
{

    private const string COPYBOOK_FIELD = """
                                          ^\s*(?<lvl>\d{2})\s+
                                          (?<name>[A-Z0-9\-]+)
                                          (?:\s+REDEFINES\s+(?<redefines>[A-Z0-9\-]+))?
                                          (?:\s+PIC\s+(?<pic>[^.]+?))?
                                          (?:\s+USAGE\s+(?:IS\s+)?(?<usage>[A-Z0-9\-]+))?
                                          \.
                                          """;

    private static readonly Regex runX = new(@"X{2,}(?!\()", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex run9 = new(@"9{2,}(?!\()", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex leadingZeros = new(@"([SX]9?)\((0+)(\d+)\)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex singleX = new(@"(?<=\b)X(?=\b)(?!\()", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex single9 = new(@"(?<=\b)9(?=\b)(?!\()", RegexOptions.Compiled);
    private static readonly Regex singleS9 = new(@"(?<=\b)S9(?=\b)(?!\()", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex pictureRegEx = new(@"([SX]?)(9|X)(?:\((\d+)\))?", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex lineRegEx = new (COPYBOOK_FIELD, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Compiled);

    private readonly ILogger logger = logger ?? new NullLogger<CopybookGenerator>();
    private static readonly string toolName = typeof(CopybookGenerator).Assembly.GetName().Name ?? "CopybookGenerator";

    public async Task<(bool Success, ICollection<string> Errors)> GenerateCSharpFromCopybooks(DirectoryInfo outputDirectory, DirectoryInfo copybookLayouts, string copybookLayoutSearchPattern = "*.cpy")
    {
        var errors = new List<string>();
        var success = true;
        var cnt = 0;
        foreach (var fileInfo in copybookLayouts.EnumerateFiles(copybookLayoutSearchPattern, SearchOption.TopDirectoryOnly))
        {
            cnt++;
            var (successLocal, error) = await GenerateCSharpFromCopybook(outputDirectory, fileInfo);
            if (successLocal)
                continue;
            success = false;
            logger.LogError("Unable to load copybook {FileInfoName}: {Error}", fileInfo.Name, error);
            errors.Add($"Unable to load copybook {fileInfo.Name}: {error}");
        }

        if (cnt != 0)
            return (success, errors);

        logger.LogError("No copybooks found in {CopybookLayoutsFullName}", copybookLayouts.FullName);
        errors.Add($"No copybooks found in {copybookLayouts.FullName}");
        return (false, errors);
    }

    public async Task<(bool Success, string Error)> GenerateCSharpFromCopybook(DirectoryInfo outputDirectory, FileInfo incomingCopybookLayout)
    {
        try
        {
            Console.WriteLine($"Loading {incomingCopybookLayout.Name}");
            Console.WriteLine($"\tReading");

            var content = await incomingCopybookLayout.OpenText().ReadToEndAsync();
            var rawClassName = Path.GetFileNameWithoutExtension(incomingCopybookLayout.FullName);
            var className = ToValidClassName(rawClassName);

            Console.WriteLine($"\tParsing");

            var tree = ParseCopybook(content);

            Console.WriteLine($"\tConverting to C#");

            var contents = EmitCSharp(tree, className, incomingCopybookLayout.Name, desiredNamespace);
            var bytes = Encoding.UTF8.GetBytes(contents);
            var byteMemory = bytes.AsMemory();
            var outputPath = Path.Combine(outputDirectory.FullName, $"{className}.g.cs");
            var outputFile = new FileInfo(outputPath);

            Console.WriteLine($"\tGenerating {outputFile.Name}");

            await using var stream = outputFile.Open(FileMode.Create, FileAccess.Write, FileShare.None);
            await stream.WriteAsync(byteMemory);
            await stream.FlushAsync();
            stream.Close();

            if (outputFile.Exists)
            {
                Console.WriteLine($"\tDone. Size:{outputFile.Length}");
                return (true, string.Empty);
            }
            await Console.Error.WriteLineAsync($"\tERROR: Unable to create {outputFile.FullName}");
            return (false, $"ERROR: Unable to create {outputFile.FullName}");
        }
        catch (Exception ex)
        {
            var msg = $"Unable to process the incoming copybook: {incomingCopybookLayout.FullName}";
            logger.LogError(ex, msg);
            await Console.Error.WriteLineAsync(msg);
            return (false, msg);
        }
    }

    private static List<CopyItem> ParseCopybook(string text)
    {
        // ① Normalize the source into "logical lines" (each ends with '.')
        var logicalLines = new List<string>();
        var lines = new StringBuilder();

        foreach (var splitText in text.Split('\n'))
        {
            var line = splitText[..Math.Max(0, splitText.Length)].TrimEnd('\r'); // strip CR
            if (line.TrimStart().StartsWith('*')) continue;         // comment, skip
            lines.Append(' ').Append(line.Trim());
            if (line.Contains('.')) // COBOL logical line ends at '.'
            {
                logicalLines.Add(lines.ToString());
                lines.Clear();
            }
        }

        // ② Regex that tolerates leading spaces + optional newline after REDEFINES
        
        var root = new CopyItem(0, "ROOT", "ROOT", null, null, null, false, []);
        var stack = new Stack<CopyItem>();
        stack.Push(root);

        var readOnly = false;
        // Track occurrences of each COBOL name so we can produce unique CLR identifiers (e.g., FILLER, FILLER2, FILLER3)
        var nameCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        foreach (var logicalLine in logicalLines)
        {
            // (1) Skip empty lines
            var m = lineRegEx.Match(logicalLine);
            if (!m.Success) continue; // non‑data line (comments, titles, fillers)

            var lvl = int.Parse(m.Groups["lvl"].Value);
            var name = m.Groups["name"].Value.ToUpperInvariant();
            var redefines = m.Groups["redefines"].Success ? m.Groups["redefines"].Value.ToUpperInvariant() : null;
            var pic = m.Groups["pic"].Success ? m.Groups["pic"].Value.Trim() : null;

            string? picture = null;
            string? usage = null;

            // (2) Handle PIC clause
            if (pic is not null)
            {
                var parts = pic.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                picture = parts[0]; // first token
                if (parts.Length > 1)
                {
                    var last = parts[^1].ToUpperInvariant();
                    if (last is "COMP" or "COMP-3" or "COMP-4" or "COMP-5" or "BINARY" or "PACKED-DECIMAL")
                    {
                        usage = last; // second token is usage
                        picture = string.Join(' ', parts[..^1]); // all but last
                    }
                    else
                    {
                        picture = pic; // keep everything
                    }
                }
            }

            // (3) Clean up the picture clause
            if (picture is not null)
            {
                picture = CleanPicture(picture);
            }

            // (4) KEY/RESULT markers flip the read‑only flag but are not emitted
            if (name is "KEY-FIELDS" or "RESULT-FIELDS" or "RESULTS-FIELDS")
            {
                readOnly = name is "KEY-FIELDS";
                continue;
            }

            // (5) Compute a unique CLR identifier for repeated names (e.g., FILLER, FILLER2, FILLER3)
            nameCounts.TryGetValue(name, out var count);
            count++;
            nameCounts[name] = count;
            var uniqueName = count == 1 ? name : $"{name}{count}";

            // (6) Build the tree
            var node = new CopyItem(lvl, name, uniqueName, picture, usage, redefines, readOnly, []);
            while (stack.Peek().Level >= lvl)
                stack.Pop();
            stack.Peek().Children.Add(node);
            stack.Push(node);
        }
        return root.Children; // ← now contains items from your sample

    }

    private static string EmitCSharp(IEnumerable<CopyItem> items, string className, string copybookLayoutName, string desiredNamespace)
    {

        var offsetLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase); // COBOL name → offset
        var cursor = 0; // running byte offset

        var classBuilder = new StringBuilder();
        classBuilder.AppendLine("//------------------------------------------------------------------------------");
        classBuilder.AppendLine("//<auto-generated>");
        classBuilder.AppendLine($"// This code was generated by {toolName} at {DateTime.Now:g}");
        classBuilder.AppendLine("// Changes to this file may cause incorrect behavior and will be lost if");
        classBuilder.AppendLine("// the code is regenerated.");
        classBuilder.AppendLine($"// Generated from {copybookLayoutName}");
        classBuilder.AppendLine("//</auto-generated>");
        classBuilder.AppendLine("//------------------------------------------------------------------------------");
        classBuilder.AppendLine();
        if (!string.IsNullOrWhiteSpace(desiredNamespace))
        {
            classBuilder.AppendLine($"namespace {desiredNamespace};");
            classBuilder.AppendLine();
        }
        classBuilder.AppendLine("using System;");
        classBuilder.AppendLine("using System.Runtime.InteropServices;");
        classBuilder.AppendLine("using Wsdot.Idl.Ifx.Mainframe;");
        classBuilder.AppendLine();
        classBuilder.AppendLine($"public partial class {className}");
        classBuilder.AppendLine("{");
        classBuilder.AppendLine();
        EmitChildren(items, 1, classBuilder, ref cursor, offsetLookup);
        classBuilder.AppendLine("}");
        classBuilder.AppendLine();
        classBuilder.AppendLine($"// __END__");
        return classBuilder.ToString();

    }

    static void EmitChildren(IEnumerable<CopyItem> children, int indent, StringBuilder sb, ref int cursorRef, Dictionary<string, int> offsetLookupDictionary)
    {
        // Build a sibling-scope suppression set: any item that is the target of a REDEFINES will not be emitted.
        var suppressTargets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var items = children.Where(c => !string.IsNullOrWhiteSpace(c.Redefines)).ToList();
        items.ForEach(c => suppressTargets.Add(c.Redefines!));
        
        var padding = new string(' ', indent * 4);
        foreach (var item in items)
        {
            var clrIdent = ToValidClassName(item.UniqueName);

            // GROUP -----------------------------------------------------------
            if (item.Children.Count > 0)
            {
                // If the group REDEFINES another item, base the group at the redefined item's offset.
                var groupStart = (item.Redefines is not null && offsetLookupDictionary.TryGetValue(item.Redefines, out var redefOff))
                    ? redefOff
                    : cursorRef;

                // Remember the group's offset by original COBOL name for any later lookups.
                offsetLookupDictionary.TryAdd(item.Name, groupStart);

                // Emit the group using a local cursor starting at the group's base.
                sb.AppendLine($"{padding}public sealed class {clrIdent}");
                sb.AppendLine($"{padding}{{");
                var localCursor = groupStart;
                EmitChildren(item.Children, indent + 1, sb, ref localCursor, offsetLookupDictionary);
                sb.AppendLine($"{padding}}}");
                sb.AppendLine();
                sb.AppendLine($"{padding}public {clrIdent}? {clrIdent}Group {{ get; set; }}");
                sb.AppendLine();

                // Advance the outer cursor only if this group does NOT redefine another item.
                if (item.Redefines is null)
                    cursorRef = localCursor;

                continue;
            }

            // ELEMENTARY ------------------------------------------------------
            var length = GetLength(item.Picture!, item.Usage);
            var offset = (item.Redefines is not null && offsetLookupDictionary.TryGetValue(item.Redefines, out var o))
                ? o
                : cursorRef;

            // Remember the offset for this COBOL name (used by later REDEFINES).
            offsetLookupDictionary.TryAdd(item.Name, offset);

            // Advance running cursor only if NOT a redefine (redefines share the same base).
            if (item.Redefines is null)
                cursorRef += length;

            // Suppress emission if this item is the target of a REDEFINES in this sibling scope.
            if (suppressTargets.Contains(item.Name))
                continue;

            var attr = $"""[CopybookField(Level={item.Level}, Name="{item.Name}", Picture="{item.Picture}", Usage="{item.Usage}", Redefines="{item.Redefines}", ReadOnly={item.ReadOnly.ToString().ToLower()}, Offset={offset}, Length={length})]""";

            var clrType = InferClrType(item);
            var accessors = item.ReadOnly ? "{ get; init; }" : "{ get; set; }";

            sb.AppendLine($"{padding}{attr}");
            sb.AppendLine($"{padding}public {clrType}? {clrIdent} {accessors}");
            sb.AppendLine();

            if (!string.IsNullOrWhiteSpace(item.Usage))
                Console.WriteLine($"\tUsage = {item.Usage}");
        }
    }

    private static string InferClrType(CopyItem item)
    {

        if (item.Picture is null)
            return "string"; // group headers

        var pic = item.Picture.ToUpperInvariant().Trim();
        var usage = item.Usage?.ToUpperInvariant() ?? "";

        // 1) Alpha → string
        if (pic.Contains('X') || pic.Contains('A'))
            return "string";

        // 2) Packed decimal (sign nibble) → decimal
        if (usage.StartsWith("COMP-3") || usage.Contains("PACKED"))
            return "decimal";

        var hasV = pic.Contains('V');
        // 3) Signed numeric (S9…)
        if (pic.StartsWith("S9"))
            return hasV
                ? "decimal"
                : "int";

        // 4) Unsigned numeric (9…)
        if (pic.StartsWith('9'))
            return hasV
                ? "decimal"
                : "uint";

        // 5) Fallback
        return hasV
            ? "decimal"
            : "int";

    }

    public static string ToPascal(string cobol)
    {
        return string.Concat(cobol.Split(['-', '_'], StringSplitOptions.RemoveEmptyEntries).Select(s => char.ToUpperInvariant(s[0]) + s[1..].ToLowerInvariant()));
    }

    public static string ToValidClassName(string rawName)
    {
        // Replace invalid characters with underscores
        var cleaned = rawName.Replace('-', '_').Replace('.', '_').Trim();

        // If the first character is not a letter or underscore, prefix with underscore
        if (string.IsNullOrEmpty(cleaned) || !(char.IsLetter(cleaned[0]) || cleaned[0] == '_'))
        {
            cleaned = "_" + cleaned;
        }

        // Ensure all characters are valid (letters, digits, or underscores)
        var sb = new StringBuilder();
        foreach (var c in cleaned)
        {
            sb.Append(char.IsLetterOrDigit(c) || c == '_' ? c : '_');
        }

        // PascalCase the result (split on underscores, capitalize each part)
        var parts = sb.ToString().Split('_', StringSplitOptions.RemoveEmptyEntries);
        var pascal = string.Concat(parts.Select(p => char.ToUpperInvariant(p[0]) + p[1..].ToLowerInvariant()));

        // Preserve leading underscores (e.g., for names starting with digits)
        var leadingUnderscores = sb.ToString().TakeWhile(c => c == '_').Count();
        if (leadingUnderscores > 0)
            pascal = new string('_', leadingUnderscores) + pascal;

        return pascal;
    }

    #region Embedded Types
    // Name: original COBOL name; UniqueName: unique identifier for CLR (e.g., FILLER, FILLER2, FILLER3)
    private sealed record CopyItem(int Level, string Name, string UniqueName, string? Picture, string? Usage, string? Redefines, bool ReadOnly, List<CopyItem> Children);
    #endregion Embedded Types

    #region Helpers
    /// <summary>
    /// Collapse straight runs of X or 9 into the parenthesised form.
    /// e.g.  XXXX      →  X(4)
    ///       9999V99   →  9(4)V99
    /// </summary>
    public static string CleanPicture(string picture)
    {
        if (string.IsNullOrEmpty(picture))
            return picture;

        picture = runX.Replace(picture, m => $"X({m.Length})");
        picture = run9.Replace(picture, m => $"9({m.Length})");
        picture = singleX.Replace(picture, "X(1)");
        picture = singleS9.Replace(picture, "S9(1)");
        picture = single9.Replace(picture, "9(1)");
        picture = leadingZeros.Replace(picture, m => $"{m.Groups[1].Value}({m.Groups[3].Value})");
        return picture;
    }

    /// <summary>Return (offsetDelta, lengthInBytes) given a PIC + USAGE.</summary>
    public static int GetLength(string picture, string? usage)
    {

        usage = (usage ?? string.Empty).ToUpperInvariant();
        
        // Count digits & X’s
        var (digits, alphas) = pictureRegEx
            .Matches(picture)
            .Select(m => (
                Character: char.ToUpperInvariant(m.Groups[2].Value[0]),       // (9|X)
                Count: m.Groups[3].Success ? int.Parse(m.Groups[3].Value) : 1 // (\d+)
            ))
            .Aggregate((Digits: 0, Alphas: 0), (output, input) => input.Character == 'X' ? (output.Digits, output.Alphas + input.Count) : (output.Digits + input.Count, output.Alphas));


        // default: zoned – each X or 9 is a byte; implied V costs 0
        return usage switch
        {
            "COMP-3" or "PACKED-DECIMAL" => (digits + 1) / 2,
            "COMP" or "BINARY" => digits switch
            {
                <= 4 => 2,
                <= 9 => 4,
                _ => 8
            },
            _ => digits + alphas
        };
    }
    #endregion Helpers

}