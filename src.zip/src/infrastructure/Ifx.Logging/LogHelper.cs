﻿using Microsoft.Extensions.Logging;

namespace Wsdot.Idl.Ifx.Logging;

public class LogHelper
{
    /// <summary>
    /// Logs a given error level message to the given logger, with an optional parameter for an Exception if needed.
    /// This method removes the need to manually provide a null value if no Exception is provided.
    /// </summary>
    /// <param name="logger">an ILogger implementation to log the message to</param>
    /// <param name="logMessage">a string representing the error message to write to the log</param>
    /// <param name="exception">an optional Exception to capture the stack trace.  </param>
    public static void LogErrorMessage(ILogger logger, string logMessage, Exception? exception = null)
    {
        logError(logger, logMessage, exception);
    }

    /// <summary>
    /// logs a given information level message to the provided logger, with an optional parameter for an Exception if needed.
    /// This method removes the need to manually provide a null value if no Exception is provided.
    /// </summary>
    /// <param name="logger">an ILogger implementation to log the message to</param>
    /// <param name="logMessage">a string representing the information message to write to the log</param>
    /// <param name="exception">an optional Exception to capture the stack trace.  </param>
    public static void LogInformationMessage(ILogger logger, string logMessage, Exception? exception = null)
    {
        logInformation(logger, logMessage, exception);
    }

    public static void LogDebugMessage(ILogger logger, string logMessage)
    {
        logDebug(logger, logMessage, null);
    }

    public static void Log(ILogger logger, string logMessage, LogLevel logLevel = LogLevel.Debug, Exception? exception = null)
    {
        switch (logLevel)
        {
            case LogLevel.Information:
                logInformation(logger, logMessage, exception);
                break;
            case LogLevel.Error:
                logError(logger, logMessage, exception);
                break;
            default:
                logDebug(logger, logMessage, exception);
                break;
        }
    }

    private static readonly Action<ILogger, string, Exception?> logError =
        LoggerMessage.Define<string>(LogLevel.Error, new EventId(), "{Message}");

    private static readonly Action<ILogger, string, Exception?> logInformation =
        LoggerMessage.Define<string>(LogLevel.Information, new EventId(), "{Message}");

    private static readonly Action<ILogger, string, Exception?> logDebug =
        LoggerMessage.Define<string>(LogLevel.Debug, new EventId(), "{Message}");
}