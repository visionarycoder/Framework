﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace Wsdot.Idl.Ifx.Data.SqlServer;

public static class SqlHelper
{
    /// <summary>
    /// Default max retry count for SQL transient failure retries (must be > 0).
    /// </summary>
    public static int MaxRetryCount { get; set; } = 3;

    /// <summary>
    /// Default max delay between retries (must be > 0).
    /// </summary>
    public static TimeSpan MaxRetryDelay { get; set; } = TimeSpan.FromSeconds(30);

    /// <summary>
    /// Default command timeout (seconds, must be > 0).
    /// </summary>
    public static int CommandTimeout { get; set; } = 90;

    /// <summary>
    /// Builds an action configuring SqlServer options with retry + timeout.
    /// </summary>
    /// <param name="maxRetryCount">> 0</param>
    /// <param name="maxRetryDelay">Total milliseconds > 0</param>
    /// <param name="commandTimeout">> 0 (seconds)</param>
    /// <param name="errorNumbersToAdd">Additional SQL error numbers to treat as transient.</param>
    /// <exception cref="ArgumentOutOfRangeException"></exception>
    public static Action<SqlServerDbContextOptionsBuilder> GenerateSqlServerDbContextOptionsBuilder(int maxRetryCount, TimeSpan maxRetryDelay, int commandTimeout, ICollection<int>? errorNumbersToAdd = null)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxRetryCount);
        if (maxRetryDelay <= TimeSpan.Zero)
        {
            throw new ArgumentOutOfRangeException(nameof(maxRetryDelay), "Retry delay must be greater than zero.");
        }
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(commandTimeout);

        return sql =>
        {
            sql.EnableRetryOnFailure(maxRetryCount, maxRetryDelay, errorNumbersToAdd);
            sql.CommandTimeout(commandTimeout);
        };
    }

    /// <summary>
    /// Returns an action using current static defaults (fresh each call so changed static values are honored).
    /// </summary>
    public static Action<SqlServerDbContextOptionsBuilder> SqlServerDbContextOptionsBuilder => GenerateSqlServerDbContextOptionsBuilder(MaxRetryCount, MaxRetryDelay, CommandTimeout);

    /// <summary>
    /// Builds an action configuring DbContextOptions with SQL Server + current retry settings.
    /// </summary>
    public static Action<DbContextOptionsBuilder> GenerateDbContextOptionsBuilder(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            throw new ArgumentException("Connection string cannot be null or whitespace.", nameof(connectionString));
        }

        return options =>
        {
            options.UseSqlServer(connectionString, SqlServerDbContextOptionsBuilder);
#if DEBUG
            options.EnableSensitiveDataLogging();
            options.EnableDetailedErrors();
#endif
        };
    }

    /// <summary>
    /// Convenience wrapper for GenerateDbContextOptionsBuilder.
    /// </summary>
    public static Action<DbContextOptionsBuilder> DbContextOptionsBuilder(string connectionString) => GenerateDbContextOptionsBuilder(connectionString);
}
