﻿using Wsdot.Idl.Ifx.Filtering;
using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class QueryRequest : ServiceMessageRequest
{
    public Filter Filter { get; set; } = Filter.Empty;
    public Paging Paging { get; set; } = Paging.Empty;
}