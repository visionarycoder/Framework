﻿using Wsdot.Idl.Ifx.Filtering;
using Wsdot.Idl.Ifx.Models;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class QueryRequest<T> : QueryRequest 
{
    public new Filter<T> Filter { get; set; } = default;
}