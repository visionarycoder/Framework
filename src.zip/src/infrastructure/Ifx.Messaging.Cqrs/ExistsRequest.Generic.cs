﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class ExistsRequest<T> : QueryRequest<T> { }