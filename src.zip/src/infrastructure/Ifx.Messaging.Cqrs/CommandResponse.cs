﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public abstract class CommandResponse : ServiceMessageResponse
{
    public object Item { get; set; } = null!;
    public bool OperationSuccessful { get; set; }
}