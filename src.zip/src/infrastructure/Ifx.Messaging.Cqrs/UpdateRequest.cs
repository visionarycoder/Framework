﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class UpdateRequest : CommandRequest { }