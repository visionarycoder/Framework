﻿using Wsdot.Idl.Ifx.Models;
using Wsdot.Idl.Ifx.Pagination;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class QueryResponse : ServiceMessageResponse
{
    public ICollection<object> Items { get; set; } = new List<object>();
    public Paging Paging { get; set; } = Paging.Empty;
}