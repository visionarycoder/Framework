﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class DeleteResponse : CommandResponse { }