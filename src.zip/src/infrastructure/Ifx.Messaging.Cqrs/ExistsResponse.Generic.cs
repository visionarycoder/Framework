﻿using Wsdot.Idl.Ifx.Filtering;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class ExistsResponse<T> : ExistsResponse
{
    public new Filter<T> Filter { get; set; }
}