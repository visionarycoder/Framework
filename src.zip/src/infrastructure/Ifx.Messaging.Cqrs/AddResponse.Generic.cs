﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class AddResponse<T> : CommandResponse<T> { }