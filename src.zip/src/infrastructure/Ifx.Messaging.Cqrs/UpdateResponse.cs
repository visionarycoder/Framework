﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class UpdateResponse : CommandResponse { }