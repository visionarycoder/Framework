﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class FindResponse<T> : QueryResponse<T> { }