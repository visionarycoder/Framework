﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class AddRequest<T> : CommandRequest<T> { }