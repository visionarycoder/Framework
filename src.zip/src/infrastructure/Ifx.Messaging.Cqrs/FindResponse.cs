﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class FindResponse : QueryResponse { }