﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class CommandRequest : ServiceMessageRequest
{
    public object Item { get; set; } = null!;
    public bool OperationSuccessful { get; set; } = false;
}