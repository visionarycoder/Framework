﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Ifx.Services.Messaging.Cqrs.UnitTests")]