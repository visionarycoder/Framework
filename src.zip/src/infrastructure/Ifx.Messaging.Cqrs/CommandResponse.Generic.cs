﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public abstract class CommandResponse<T> : CommandResponse
{
    public new T? Item { get; set; } = default(T);
}
