﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class CommandRequest<T> : CommandRequest
{
    public new T? Item { get; set; }
}