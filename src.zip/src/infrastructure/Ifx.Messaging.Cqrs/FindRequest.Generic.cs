﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class FindRequest<T> : QueryRequest<T> { }