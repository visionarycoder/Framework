﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class UpdateRequest<T> : CommandRequest<T> { }