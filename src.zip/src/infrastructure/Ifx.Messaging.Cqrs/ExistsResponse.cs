﻿using Wsdot.Idl.Ifx.Filtering;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class ExistsResponse : ServiceMessageResponse
{
    public Filter Filter { get; set; } = Filter.Empty;
    public bool ItemExists { get; set; }
}