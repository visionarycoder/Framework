﻿using Wsdot.Idl.Ifx.Models;

namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class QueryResponse<T> : QueryResponse
{
    public new ICollection<T> Items { get; set; } = new List<T>();
}

