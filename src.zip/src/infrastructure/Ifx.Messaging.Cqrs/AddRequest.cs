﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class AddRequest : CommandRequest { }