﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class DeleteRequest<T> : CommandRequest<T> { }