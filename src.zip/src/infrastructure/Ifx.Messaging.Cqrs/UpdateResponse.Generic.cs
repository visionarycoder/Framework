﻿namespace Wsdot.Idl.Ifx.Messaging.Cqrs;

public class UpdateResponse<T> : UpdateResponse { }