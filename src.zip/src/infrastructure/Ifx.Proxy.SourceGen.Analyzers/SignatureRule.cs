﻿using System.Collections.Immutable;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Diagnostics;

namespace Wsdot.Idl.Ifx.Proxy.SourceGen.Analyzers;

[DiagnosticAnalyzer(LanguageNames.CSharp)]
public sealed class SignatureRule : DiagnosticAnalyzer
{

    public static readonly DiagnosticDescriptor Rule = new(id: "IFX001", title: "Proxy contract method signature", messageFormat: "Methods in a [ProxyContract] interface must be Task/Task<T>(IServiceMessageRequest request, CancellationToken ct)", category: "Design", DiagnosticSeverity.Error, isEnabledByDefault: true);

    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

    public override void Initialize(AnalysisContext ctx)
    {
    
        ctx.EnableConcurrentExecution();
        ctx.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
        ctx.RegisterSymbolAction(c =>
        {
            var namedTypeSymbol = (INamedTypeSymbol) c.Symbol;
            var hasAttr = namedTypeSymbol.GetAttributes().Any(a => a.AttributeClass?.ToDisplayString() == "Ifx.Proxy.ProxyContractAttribute");
            if (!hasAttr)
            {
                return;
            }

            foreach (var m in namedTypeSymbol.GetMembers().OfType<IMethodSymbol>())
            {
                if (m.MethodKind != MethodKind.Ordinary)
                {
                    continue;
                }

                var okReturn = m.ReturnType.ToDisplayString().StartsWith("System.Threading.Tasks.Task");
                var ps = m.Parameters;
                var okParams = ps.Length == 2 && ps[0].Type.ToDisplayString() == "ServiceMessageRequest" && ps[1].Type.ToDisplayString() == "System.Threading.CancellationToken";
                if (!(okReturn && okParams))
                {
                    c.ReportDiagnostic(Diagnostic.Create(Rule, m.Locations.FirstOrDefault()));
                }
            }
        }, SymbolKind.NamedType);
    }
}
